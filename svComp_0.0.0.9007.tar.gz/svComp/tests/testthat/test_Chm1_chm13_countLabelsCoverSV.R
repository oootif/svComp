# read output from Tiff's code
#install.packages("/home/users/lzhang/sanity_check_chm113/gm_cov/script_tiff/svComp")
#library("/home/users/lzhang/sanity_check_chm113/gm_cov/script_tiff/svComp")
library("svComp")
library("dplyr")

Sys.setenv(PATH="/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin:/sbin:/bin:/home/users/csecol/software/external/bin:/home/users/csecol/software/external/bedtools2-master/bin")
#source("~/scripts/readmap/readmap_ernest_luna.R")

projectFolder <- "/home/users/lzhang/sanity_check_chm113/gm_cov/pure_standard/"

girlFolder <- "/home/users3/lzhang/data/validation_sv2.0/chm113_79x_1_effcov_04132016/"
dadFolder <- "/home/users3/lzhang/data/validation_sv2.0/chm1_04012016/"
momFolder <- "/home/users3/lzhang/data/validation_sv2.0/chm13_04012016/"

smapName <- "exp_refineFinal1_merged_filter_inversions"
xmapName <- "exp_refineFinal1_merged"
xmap_girl <- readxmap(paste0(girlFolder,
                             "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                             , xmapName, ".xmap"))
rcmap_girl <- readcmap(paste0(girlFolder,
                              "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                              , xmapName, "_r.cmap"))

#### Happy Path ####
# 1. Read smap

smap_girl <- readsmap(paste0(girlFolder,
                              "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                              , smapName, ".smap"))
smap_dad <- readsmap(paste0(dadFolder,
                             "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                             , smapName, ".smap"))
smap_mom <- readsmap(paste0(momFolder,
                             "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                              , smapName, ".smap"))

# test CHM1 CHM13
# For de novo SV (do not overlap with a parent's SV for >= 1bp )
chm1_chm13_Nmix_ins <- trio_countLabelsCoverSV_svType(
  f_smap_ofs=paste0(girlFolder,
                    "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_mom=paste0(momFolder,
                             "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                              , smapName, ".smap"),
  f_xmap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_xmap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_qcmap_dad=paste0(dadFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  f_qcmap_mom=paste0(momFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  svType="insertion",
  minLen=0,
  minConf=0
)
chm1_chm13_Nmix_del <- trio_countLabelsCoverSV_svType(
  f_smap_ofs=paste0(girlFolder,
                    "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_xmap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_xmap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_qcmap_dad=paste0(dadFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  f_qcmap_mom=paste0(momFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  svType="deletion",
  minLen=0,
  minConf=0
)

# For non-denovo SV (overlap with either parents' SV for >=1bp)
chm1_chm13_Nmix_nondenovo_ins <- trio_countLabelsCoverSV_svType_nondenovo(
  f_smap_ofs=paste0(girlFolder,
                    "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_xmap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_xmap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_qcmap_dad=paste0(dadFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  f_qcmap_mom=paste0(momFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  svType= "insertion", #"deletion",
  minLen=0,
  minConf=0
)

chm1_chm13_Nmix_nondenovo_del <- trio_countLabelsCoverSV_svType_nondenovo(
  f_smap_ofs=paste0(girlFolder,
                    "output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_smap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , smapName, ".smap"),
  f_xmap_dad=paste0(dadFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_xmap_mom=paste0(momFolder,
                    "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                    , xmapName, ".xmap"),
  f_qcmap_dad=paste0(dadFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  f_qcmap_mom=paste0(momFolder,
                     "output/contigs/exp_refineFinal1_standard/refsplit_ra4784_p4618_xml160127/merged_smaps/"
                     , "exp_refineFinal1_merged_q.cmap"),
  svType= "deletion",
  minLen=0,
  minConf=0
)

# f_smap_ofs="/home/users3/lzhang/data/validation_sv2.0/chm113_177x_04072016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
# f_smap_dad="/home/users3/lzhang/data/validation_sv2.0/chm1_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
# f_smap_mom="/home/users3/lzhang/data/validation_sv2.0/chm13_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
# f_xmap_dad="/home/users3/lzhang/data/validation_sv2.0/chm1_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged.xmap"
# f_xmap_mom="/home/users3/lzhang/data/validation_sv2.0/chm13_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged.xmap"
# f_qcmap_dad="/home/users3/lzhang/data/validation_sv2.0/chm1_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged_q.cmap"
# f_qcmap_mom="/home/users3/lzhang/data/validation_sv2.0/chm13_04012016/output/contigs/exp_refineFinal1_haplotype/refsplit_ra4784_p4618_xml160127/merged_smaps/exp_refineFinal1_merged_q.cmap"
# svType= "deletion"
# minLen=0
# minConf=0


# Chm1 & Chm13 & Mixturec Lzhang
# overlapped
labels_trio <- chm1_chm13_Nmix_nondenovo_ins
nrow(labels_trio)
labels_trio <- labels_trio %>% mutate(sample=ifelse(sample=="Father","chm1","chm13"))
MoleOutputfile =paste0(projectFolder, "chm1chm13_ins_overlap_countLabelsAroundSV.txt")
write.table(labels_trio,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)
labels_trio_has_coverage_ins <- labels_trio %>% group_by(SmapEntryID) %>% filter(!any(is.na(n_alignedLabel_bf_sv))) #Filter out SV without parent GM coverage
nrow(labels_trio_has_coverage_ins)
MoleOutputfile = paste0(projectFolder, "chm1chm13_ins_overlap_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(labels_trio_has_coverage_ins,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

labels_trio <- chm1_chm13_Nmix_nondenovo_del
nrow(labels_trio)
labels_trio <- labels_trio %>% mutate(sample=ifelse(sample=="Father","chm1","chm13"))
MoleOutputfile = paste0(projectFolder, "chm1chm13_del_overlap_countLabelsAroundSV.txt")
write.table(labels_trio,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)
labels_trio_has_coverage_del <- labels_trio %>% group_by(SmapEntryID) %>% filter(!any(is.na(n_alignedLabel_bf_sv))) #Filter out SV without parent GM coverage
nrow(labels_trio_has_coverage_del)
MoleOutputfile = paste0(projectFolder, "chm1chm13_del_overlap_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(labels_trio_has_coverage_del,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

#denovo
labels_trio <- chm1_chm13_Nmix_ins
nrow(labels_trio)
labels_trio <- labels_trio %>% mutate(sample=ifelse(sample=="Father","chm1","chm13"))
MoleOutputfile = paste0(projectFolder, "chm1chm13_ins_denovo_countLabelsAroundSV.txt")
write.table(labels_trio,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)
labels_trio_has_coverage_ins <- labels_trio %>% group_by(SmapEntryID) %>% filter(!any(is.na(n_alignedLabel_bf_sv))) #Filter out SV without parent GM coverage
nrow(labels_trio_has_coverage_ins)
MoleOutputfile =paste0(projectFolder, "chm1chm13_ins_denovo_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(labels_trio_has_coverage_ins,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

labels_trio <- chm1_chm13_Nmix_del
nrow(labels_trio)
labels_trio <- labels_trio %>% mutate(sample=ifelse(sample=="Father","chm1","chm13"))
MoleOutputfile = paste0(projectFolder, "chm1chm13_del_denovo_countLabelsAroundSV.txt")
write.table(labels_trio,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)
labels_trio_has_coverage_del <- labels_trio %>% group_by(SmapEntryID) %>% filter(!any(is.na(n_alignedLabel_bf_sv))) #Filter out SV without parent GM coverage
nrow(labels_trio_has_coverage_del)
MoleOutputfile = paste0(projectFolder, "chm1chm13_del_denovo_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(labels_trio_has_coverage_del,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)