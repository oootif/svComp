library(svComp)
library(dplyr)

# smap_girl_sv <- get_sv_size(smap_girl)

xmap_girl<- readxmap(system.file("extdata","PUR_Daughter_BspQI.xmap", package="svComp"))
rcmap_girl<- readcmap(system.file("extdata","PUR_Daughter_BspQI_r.cmap", package="svComp"))

#### Happy Path ####
# 1. Read smap
# smap_girl<- readsmap("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/pur_daughter_bspqi_sm2.smap")
# smap_dad<- readsmap("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/pur_father_bspqi_sm2.smap")
smap_girl<-readsmap(system.file("extdata","pur_daughter_bspqi_sm.smap", package="svComp"))
smap_dad<- readsmap(system.file("extdata","pur_father_bspqi_sm.smap", package="svComp"))
smap_mom<- readsmap(system.file("extdata","pur_mother_bspqi_sm.smap", package="svComp"))

# 1b. Read xmap
# xmap_dad<- readxmap("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/PUR_Father_BspQI.xmap")
# xmap_mom<- readxmap("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/PUR_Mother_BspQI.xmap")


# 1c. Read _q.cmap; _r.cmap
qcmap_dad<- readcmap1("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/PUR_Father_BspQI_q.cmap")
qcmap_mom<- readcmap1("/home/users/tliang/r_script/svRTools/project_rPackage/svComp/testdata/PUR_Mother_BspQI_q.cmap")

# 2. Filter and selected usable region, seperate by deletion and insertion
smap_girl_del <- get_sv_type_minlen(smap_girl,"deletion",minLen=0)
smap_dad_del <- get_sv_type_minlen(smap_dad,"deletion",minLen=0)
smap_mom_del <- get_sv_type_minlen(smap_mom,"deletion",minLen=0)

smap_girl_ins_1k <- get_sv_type_minlen(smap_girl,"insertion",minLen=1000)
smap_dad_ins_1k <- get_sv_type_minlen(smap_dad,"insertion",minLen=1000)
smap_mom_ins_1k <- get_sv_type_minlen(smap_mom,"insertion",minLen=1000)

# 3. Convert smap to bed
bed_girl_del <- select(smap_girl_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
bed_dad_del <- select(smap_dad_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
bed_mom_del <- select(smap_mom_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

# 4. bedtool overlap SV from parents and child
bt_result_DM <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_mom_del,optString="-wao")
bt_result_DF <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_dad_del,optString="-wao")
bt_result_DM <- add_names_bedintersect(bt_result_DM)
bt_result_DF <- add_names_bedintersect(bt_result_DF)

# 5. Get de novo offspring SV
smap_girl_del_denovo <- get_offspring_denovo_sv(bt_result_DM, bt_result_DF,ref_smap=smap_girl)

# 6. Add number of sites for query in xmap data frame
labels_dad <- countLabelsOnGM_coverSV(smap_girl_del_denovo,xmap_dad,qcmap_dad)
labels_mom <- countLabelsOnGM_coverSV(smap_girl_del_denovo,xmap_mom,qcmap_mom)

# countLabelsOnGM_coverSV <- function(smap,xmap,qcmap){
# #   smap<-smap_girl_del_denovo
# #   xmap<-xmap_dad
# #   qcmap<-qcmap_dad
#
#   xmap1 <-add_numSites_to_xmap(xmap,qcmap)
#
#   sv_gm_coverage=data.frame()
#   for (entry in 1:nrow(smap)) {
# #     entry=2
#
#     # Set offspring SV line coordinates
#     offspring_chr <- smap[entry,"RefcontigID1"]
#     offsprint_x1 <- smap[entry,"RefStartPos"]
#     offsprint_x2 <- smap[entry,"RefEndPos"]
#     offsprint_y1 = offsprint_y2 = 0
#
#     start_ref_sv <- smap[entry,"RefStartIdx"] # Label ID on reference at start of SV
#     end_ref_sv <- smap[entry,"RefEndIdx"] # Label ID on reference at the end of SV
#
#     # Set parents GM coordinates
#     xmap1_gm <- filter(xmap1,RefcontigID==offspring_chr & RefStartPos<offsprint_x1 & RefEndPos>offsprint_x2)
#
#     if(nrow(xmap1_gm)>0){
#       #Get number of labels from SV to end of genome map
#       alignment_list <- rbind(lapply(xmap1_gm$Alignment,split_alignment))
#
#       xmap1_gm <- cbind(xmap1_gm,filter(split_alignment(xmap1_gm$Alignment),ref==start_ref_sv) %>% mutate(startLabel=qry) %>% select(startLabel)) # SV starting label on reference
#       xmap1_gm <- cbind(xmap1_gm,filter(split_alignment(xmap1_gm$Alignment),ref==end_ref_sv) %>% mutate(endLabel=qry) %>% select(endLabel)) # SV ending label on reference
#
#       xmap1_gm$n_alignedLabel_bf_sv <- lapply(alignment_list,function(df) nrow(unique(filter(df,ref<start_ref_sv)%>%select(qry)))) # Number of aligned labels on GM before the start of SV
#       xmap1_gm$n_alignedLabel_af_sv <- lapply(alignment_list,function(df) nrow(unique(filter(df,ref>end_ref_sv)%>%select(qry)))) # Number of aligned labels on GM after the end of SV
#
#       # Set number of labels on GM before the start of SV, and after the end of SV
#       xmap1_gm <- xmap1_gm %>% mutate(n_allLabel_bf_sv=min(startLabel,endLabel),n_allLabel_af_sv=NumSites-max(startLabel,endLabel)+1)
#
#       # Select wanted columns from xmap and smap
#       xmap_t1 <- xmap1_gm %>% select(1,QryContigID,RefcontigID,RefStartPos, RefEndPos, Confidence,n_alignedLabel_bf_sv,n_alignedLabel_af_sv,n_allLabel_bf_sv,n_allLabel_af_sv)
#       smap_t1 <- smap[entry,] %>% mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence) %>% select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap)
#
#       #   sv_gm_coverage <- full_join(smap_t1,xmap_t1)
#       sv_gm_coverage <- rbind(sv_gm_coverage,full_join(smap_t1,xmap_t1,by="RefcontigID"))
#     } else {
#       # No genome map is found covering the SV region
#       smap_t1 <- smap[entry,] %>% mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence) %>% select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap)
#       sv_gm_coverage <- rbind.fill(sv_gm_coverage,smap_t1)
#     }
#
#   }
#
#   return(sv_gm_coverage)
# }



# xmap_dad1 <-add_numSites_to_xmap(xmap_dad,qcmap_dad)
# xmap_mom1 <-add_numSites_to_xmap(xmap_mom,qcmap_mom)
#
#
# sv_gm_coverage=data.frame()
# # 7. Draw offspring SV, and the GM from parents that overlap the SV
# for (entry in 1:nrow(smap_girl_del_denovo)) {
# #   entry=1
#
#   # Set offspring SV line coordinates
#   offspring_chr <- smap_girl_del_denovo[entry,"RefcontigID1"]
#   offsprint_x1 <- smap_girl_del_denovo[entry,"RefStartPos"]
#   offsprint_x2 <- smap_girl_del_denovo[entry,"RefEndPos"]
#   offsprint_y1 = offsprint_y2 = 0
#
#   start_ref_sv <- smap_girl_del_denovo[entry,"RefStartIdx"] # Label ID on reference at start of SV
#   end_ref_sv <- smap_girl_del_denovo[entry,"RefEndIdx"] # Label ID on reference at the end of SV
#
#   # Set parents GM coordinates
#   xmap_dad1_gm <- filter(xmap_dad1,RefcontigID==offspring_chr & RefStartPos<offsprint_x1 & RefEndPos>offsprint_x2)
#   xmap_mom1_gm <- filter(xmap_mom1,RefcontigID==offspring_chr & RefStartPos<offsprint_x1 & RefEndPos>offsprint_x2)
#
#   #Get number of labels from SV to end of genome map
#   alignment_list <- rbind(lapply(xmap_dad1_gm$Alignment,split_alignment))
#
#   xmap_dad1_gm <- cbind(xmap_dad1_gm,filter(split_alignment(xmap_dad1_gm$Alignment),ref==start_ref_sv) %>% mutate(startLabel=qry) %>% select(startLabel)) # SV starting label on reference
#   xmap_dad1_gm <- cbind(xmap_dad1_gm,filter(split_alignment(xmap_dad1_gm$Alignment),ref==end_ref_sv) %>% mutate(endLabel=qry) %>% select(endLabel)) # SV ending label on reference
#
#   xmap_dad1_gm$n_alignedLabel_bf_sv <- lapply(alignment_list,function(df) nrow(unique(filter(df,ref<start_ref_sv)%>%select(qry)))) # Number of aligned labels on GM before the start of SV
#   xmap_dad1_gm$n_alignedLabel_af_sv <- lapply(alignment_list,function(df) nrow(unique(filter(df,ref>end_ref_sv)%>%select(qry)))) # Number of aligned labels on GM after the end of SV
#
#   # Set number of labels on GM before the start of SV, and after the end of SV
#   xmap_dad1_gm <- xmap_dad1_gm %>% mutate(n_allLabel_bf_sv=min(startLabel,endLabel),n_allLabel_af_sv=NumSites-max(startLabel,endLabel)+1)
#
#   # Select wanted columns from xmap and smap
#   xmap_t1 <- xmap_dad1_gm %>% select(1,QryContigID,RefcontigID,RefStartPos, RefEndPos, Confidence,n_alignedLabel_bf_sv,n_alignedLabel_af_sv,n_allLabel_bf_sv,n_allLabel_af_sv)
#   smap_t1 <- smap_girl_del_denovo[entry,] %>% mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos) %>% select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap)
#
# #   sv_gm_coverage <- full_join(smap_t1,xmap_t1)
#   sv_gm_coverage <- rbind(sv_gm_coverage,full_join(smap_t1,xmap_t1,by="RefcontigID"))
# }
#
#
#
#
