# test_svComp_pkg.R

library(svComp)
library(dplyr)

# smap_girl_sv <- get_sv_size(smap_girl)

xmap_girl<- readxmap(system.file("extdata","PUR_Daughter_BspQI.xmap", package="svComp"))
rcmap_girl<- readcmap(system.file("extdata","PUR_Daughter_BspQI_r.cmap", package="svComp"))

#### Happy Path ####
# 1. Read smap
smap_girl<- readsmap(system.file("extdata","pur_daughter_bspqi_sm.smap", package="svComp"))
smap_dad<- readsmap(system.file("extdata","pur_father_bspqi_sm.smap", package="svComp"))
smap_mom<- readsmap(system.file("extdata","pur_mother_bspqi_sm.smap", package="svComp"))

# 2. Filter and selected usable region, seperate by deletion and insertion
smap_girl_del <- get_sv_type_minlen(smap_girl,"deletion",0)
smap_dad_del <- get_sv_type_minlen(smap_dad,"deletion",0)
smap_mom_del <- get_sv_type_minlen(smap_mom,"deletion",0)

smap_girl_ins_1k <- get_sv_type_minlen(smap_girl,"insertion",1000)
smap_dad_ins_1k <- get_sv_type_minlen(smap_dad,"insertion",1000)
smap_mom_ins_1k <- get_sv_type_minlen(smap_mom,"insertion",1000)

# 3. Convert smap to bed
bed_girl_del <- select(smap_girl_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
bed_dad_del <- select(smap_dad_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
bed_mom_del <- select(smap_mom_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

# 4. bedtool overlap SV from parents and child
bt_result_DM <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_mom_del,optString="-wao")
bt_result_DF <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_dad_del,optString="-wao")

# 5. Add buffer to bed
bed_girl_del_5kext <- bed_add_buffer(bed_girl_del,buffer=5000)

# 6. bedtool overlap SV for bed with buffer region

# 7. Read bedtools multiinter result (overlap by 1bp)
multiinter_result <- read.delim2(system.file("extdata","overlap_del.multiinter", package="svComp"),header=TRUE,sep="\t")
multiinter_result2 <- read.delim2(system.file("extdata","overlap_ins.multiinter", package="svComp"),header=TRUE,sep="\t")

# 8. draw venn diagram
options(java.home="C:\\Program Files\\Java\\jdk1.8.0_25\\jre\\")
library(venneuler)
venn3 <- get_3_venn_counts(multiinter_result2)
child_denovo_rate <- venn3[1]/sum(venn3[4],venn3[5],venn3[7])
v <- venneuler(venn3)
v$labels[1] <- paste0(v$labels[1]," (",child_denovo_rate*100,"% de novo)")
plot(v)

# 9.


plot_venneuler <- function(venn){
  v <- venn
  v_rank <- cbind(x=rank(v$centers[,'x']),y=rank(v$centers[,'y']))
  vdf <- data.frame(v$centers)
  max_x_idname <- names(which.max(v$centers[,'x']))
  max_y_idname <- names(which.max(v$centers[,'y']))
  last_idname <- names(!which.max)
  child_x = v$centers['Child','x']
  child_y = v$centers['Child','x']+(v$diameters['Child']/1.6)
  father_x =
  text(x=v$centers['Child','x'],y=v$centers['Child','x']+(v$diameters['Child']/1.6),labels='Child',col="black")

  plot(venn)
}
plot_venneuler(v)
######' @ importFrom(dplyr,mutate)
#
#
#
# df2 <- add_buffer(df1)
#
# df_list <- sv_size_stratify(df1,size_groups) #?
#
# df_list <- sv_confidence_stratify(df1)
#
# smap2bed()
head(smap_girl)


smap2bed <- function(smap){
  select(smap,RefcontigID1,RefStartPos)
}

#
# overlap2bed(bed1, bed2)
#
# overlap3bed(bed1, bed2, bed3)

## will be useful
# file.path()

