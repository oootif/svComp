library(svComp)
library(dplyr)


smap_girl<- readsmap(system.file("extdata","PUR_Daughter_BspQI.smap", package="svComp"))
smap_girl_del <- get_sv_type_minlen(smap_girl,"deletion",minConf = 3)
smap_girl_ins <- get_sv_type_minlen(smap_girl,"insertion",minConf = 3)



p<-plot_svSize_distribution(smap_girl_del, title="PUR Daughter Deletion Calls Distribution")
p2<-plot_svSize_distribution(smap_girl_ins, title="PUR Daughter Insertion Calls Distribution")


# 2 enzymes SV merging.
# Read result from bedtools merge, and filter by SV size ratio.
del_merge <- read.delim("./svComp/inst/extdata/PUR_Daughter_BspQI_sort_del_mincon3_merge.bed",header=F,stringsAsFactors=F)
colnames(del_merge) <- c("chr","start","end","id","svSize")
head(del_merge)
sv_sizes <- lapply(del_merge$svSize, filter_sv_by_similar_size)
sv_sizes_filter <- unlist(sv_sizes)
sv_sizes_filter <- list(sv_sizes_filter)
p3<-plot_hist_distribution(sv_sizes_filter)



p4 <- p+coord_cartesian(xlim=c(0,20000),ylim=c(0,125))
p5 <- p3+coord_cartesian(xlim=c(0,20000),ylim=c(0,125))
grid.arrange(p4, p5, nrow=2, ncol=1)

pushViewport(viewport(layout = grid.layout(2, 1)))
vplayout <- function(x, y)
  viewport(layout.pos.row = x, layout.pos.col = y)
#arrange time series
print(p, vp = vplayout(1, 1))
print(p3, vp = vplayout(2, 1))
#arrange shadows
print(prects, vp=vplayout(1:2,1))

plot_ly(x=sv4plot$sv_sizes_filter,opacity=0.6,type="histogram") %>% add_trace(x=smap_girl_del$svSize)%>% layout(barmode="overlay")

library(plotly)
plot_ly(x=smap_girl_del$svSize,opacity=0.6,type="histogram") %>% add_trace(x=smap_girl_ins) %>% layout(barmode="overlay")
plot_ly(x=p,opacity=0.6,type="histogram") %>% add_trace(x=p2) %>% layout(barmode="overlay")

ggplotly()

ggFrequencySeries <- function(data){
  library(ggplot2)
  data = data.frame(data)
  names <- colnames(data)
  bin.width <- 100
  g <- ggplot(data)+geom_histogram(binwidth=bin.width)
  g <- g + geom_freqpoly(aes_string(x=names[[2]], colour=names[[1]]))
  plot(g)
  return(g)
}

data1 <- data.frame(smap_girl_del$svSize)
a <- cbind("before_filter",smap_girl_del$svSize)
b <- cbind("after_filter",sv4plot$sv_sizes_filter)
d <- rbind(a,b)

