Collapse_homozygous_outputsmap<-function(smappath, outputname){
  source("/home/users/elam/rscripts/readmaps.R")
  source("/home/users/elam/rscripts/paste0.R")
  #smappath<-"/home/users2/ahastie/data/1000genomes/SV/PUR_Father_BspQI-CP_HG00731_EXP_REFINEFINAL1_minlen0mincon3.smap"
  
  #out<-basename(smappath)
  smap<-readSMap(smappath)
  nogroup<-smap[smap$GenotypeGroup == "-1",]
  #print(nrow(nogroup))   ###Number of SVs not involved in homozygous
  groupspre<-unique(smap$GenotypeGroup)
  groups<-groupspre[groupspre != "-1"]
  withgroups<-smap[smap$GenotypeGroup %in% groups,]
  #print(nrow(withgroups))     ###Number of SVs involved in homozygous)
  
  withgroupsheter<-withgroups[withgroups$Zygosity == "heterozygous" | withgroups$Zygosity == "unknown",]
  nrow(withgroupsheter)
  
  withgroupshomo<-withgroups[withgroups$Zygosity == "homozygous",]
  nrow(withgroupshomo)
  #homogroupnum<-data.frame(table(withgroupshomo$GenotypeGroup))
  
  #homogrouponce <- homogroupnum[homogroupnum$Freq ==1,]
  #homogrouponcegroupnum<-homogrouponce$Var1
  #homoonce<-withgroupshomo[withgroupshomo$GenotypeGroup %in% homogrouponcegroupnum,]     ###These are homo SVs that has group number but only happen once.
  
  ##################################################################################
  
  homogroupnumber<-withgroupshomo$GenotypeGroup
  nonduphomogroupnumber<-homogroupnumber[!duplicated(homogroupnumber)]
  length(nonduphomogroupnumber)
  #write.table(withgroupshomo, file = "/home/users/jlee/ThousandGenomes/Homozygous_Collapsed/test.smap")
  ##################################################################################
  
  
  get_highest_conf<-function(groupnumber){
    homo<-withgroupshomo[withgroupshomo$GenotypeGroup == groupnumber, ]
    maxconf<-max(homo$Confidence)
    get<-homo[homo$Confidence == maxconf,]
    if(dim(get)[1] >1){
      get<-get[1,]
    }
    return(get)
  }
  
  collapsed<-lapply(nonduphomogroupnumber, get_highest_conf)    ###Get the one with highest conf for the same group number
  
  collapsed<-do.call(rbind,collapsed)
  nrow(collapsed)
  
  ###get the one with higher confidence. 
  #collapsed<-withgroupshomo[!duplicated(withgroupshomo$GenotypeGroup),]
  
  
  #print(nrow(collapsed))       ###After collapsing homozygous SV calls (Basically same SV called twice)
  
  output<-rbind(collapsed, withgroupsheter, nogroup)
  nrow(output)
  
  header0 <- readLines(smappath,n=100) #find header lines
  header <- header0[regexpr("^#",header0)>=0]
  cat(header, file = paste0(outputname, "_homocollapsed.smap"), sep ="\n")
  #outputname<-substr(smappath,1,nchar(smappath)-4)
  write.table(output, file = paste0(outputname, "_homocollapsed.smap"), append = T, quote=F , row.names = F, col.names =F, sep ="\t")
  print(nrow(output))
  
}