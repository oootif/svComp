library(testthat)
library(svComp)

test_check("svComp")
