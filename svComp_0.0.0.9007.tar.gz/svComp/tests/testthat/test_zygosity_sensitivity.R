# Overlap Pui and BNG. Check for Homozygous vs. Heterozygous sensitivity

pui_del <- read.table(file="/home/users/tliang/linux_projects/20160413_CEPH_Pui/pui_paper/Supplementary_2_Table1_deletion_svSize.txt",
                      header = TRUE,sep="\t",dec=".",fill = TRUE,comment.char="")

# Low stringency Zygosity calls
NA12878_del_pui <- pui_del %>% filter(!is.na(NA12878)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian),Zygosity=ifelse((grepl("del",NA12878) & grepl("\\+",NA12878)), "heterozygous","homozygous")) %>%
  select(1:3,id,svSize_med_filtByCv,Zygosity,NA12878)


# High stringency Zygosity calls
# Deletion
NA12878_del_pui <- pui_del %>% filter(!is.na(NA12878)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian),Zygosity=ifelse(grepl("^del/\\+$",NA12878),"heterozygous",ifelse(grepl("^del/del$",NA12878),"homozygous","unknown"))) %>%
  select(1:3,id,svSize_med_filtByCv,Zygosity,NA12878)
# Should I add SV size filter?

NA12878_del_pui_20kb <- add_buffer(NA12878_del_pui,buffer=20000)

NA12878_del_het_pui <- filter(NA12878_del_pui, Zygosity=="heterozygous") %>% select(-Zygosity)
NA12878_del_het_pui_20kb <- add_buffer(NA12878_del_het_pui,buffer=20000)

NA12878_del_hom_pui <- filter(NA12878_del_pui, Zygosity=="homozygous") %>% select(-Zygosity)
NA12878_del_hom_pui_20kb <- add_buffer(NA12878_del_hom_pui,buffer=20000)



# Insertion
pui_ins <- read.table(file="/home/users/tliang/linux_projects/20160413_CEPH_Pui/pui_paper/Supplementary_3_Table2_insertion_svSize.txt",header = TRUE,sep="\t",dec=".",fill = TRUE,comment.char="")
NA12878_ins_pui <- pui_ins %>% filter(!is.na(NA12878)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian),Zygosity=ifelse(grepl("^ins/\\+$",NA12878),"heterozygous",ifelse(grepl("^ins/ins$",NA12878),"homozygous","unknown"))) %>%
  select(1:3,id,svSize_med_filtByCv,Zygosity,NA12878)

NA12878_ins_pui_20kb <- add_buffer(NA12878_ins_pui,buffer=20000)

NA12878_ins_het_pui <- filter(NA12878_ins_pui, Zygosity=="heterozygous") %>% select(-Zygosity)
NA12878_ins_het_pui_20kb <- add_buffer(NA12878_ins_het_pui,buffer=20000)

NA12878_ins_hom_pui <- filter(NA12878_ins_pui, Zygosity=="homozygous") %>% select(-Zygosity)
NA12878_ins_hom_pui_20kb <- add_buffer(NA12878_ins_hom_pui,buffer=20000)

# All
NA12878_all_pui_20kb <- rbind(NA12878_del_pui_20kb,NA12878_ins_pui_20kb)

# BNG data
NA12878_del_all_con3 <- trio_hap_refsplit_con3 %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence.smap > 3, Type=="deletion") %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique

NA12878_ins_all_con3 <- trio_hap_refsplit_con3 %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence.smap > 3, Type=="insertion") %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique

NA12878_del_hom_con3 <- trio_hap_refsplit_con3 %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>%
  filter(Confidence.smap > 3, Type=="deletion", Zygosity=="homozygous") %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique
NA12878_del_het_con3 <- trio_hap_refsplit_con3 %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>%
  filter(Confidence.smap > 3, Type=="deletion", Zygosity=="heterozygous") %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique

NA12878_del_overlaped_con3 <- trio_del_hap_refsplit_nondenovo %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>%
  filter(Confidence.smap > 3, Type=="deletion") %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique

result_del_hom <- overlap_bed_svSizeRatio(bed1=NA12878_del_hom_pui_20kb,bed2=NA12878_del_all_con3)# Add 20kb buffer
result_del_het <- overlap_bed_svSizeRatio(bed1=NA12878_del_het_pui_20kb,bed2=NA12878_del_all_con3)# Add 20kb buffer
result_del_hom
result_del_het

result_ins_hom <- overlap_bed_svSizeRatio(bed1=NA12878_ins_hom_pui_20kb,bed2=NA12878_ins_all_con3)# Add 20kb buffer
result_ins_het <- overlap_bed_svSizeRatio(bed1=NA12878_ins_het_pui_20kb,bed2=NA12878_ins_all_con3)# Add 20kb buffer
result_ins_hom
result_ins_het

result2_del <- overlap_bed_svSizeRatio(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_all_con3)# Add 20kb buffer
result3 <- overlap_bed_svSizeRatio(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_hom_con3)# Add 20kb buffer, homozygous, deletion
result4 <- overlap_bed_svSizeRatio(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_het_con3)# Add 20kb buffer, heterozygous, deletion

result2_ins <- overlap_bed_svSizeRatio(bed1=NA12878_ins_pui_20kb,bed2=NA12878_ins_all_con3)# Add 20kb buffer

