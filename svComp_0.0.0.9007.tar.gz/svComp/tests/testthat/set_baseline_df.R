
set_baseline_df <- function(dataframe){
  project="/home/users/tliang/r_script/svRTools/project_rPackage/svComp"
  output = paste0(project,"/tests/baseline_ceph_del.txt")
  write.table(trio_del_hap_refsplit,file=output,quote=F,sep="\t",col.names=T,row.names=F)
}
