devtools::install_github('eddelbuettel/BH')
devtools::install_github('jayhesselberth/valr')
devtools::install_github('jayhesselberth/dplyr')

devtools::install_github("klutometis/roxygen")
setwd("../../project_rPackage")
create("svComp")

#Add required packages to DESCRIPTION file
devtools::use_package("data.table")
devtools::use_package("plyr")
devtools::use_package("dplyr")
devtools::use_package("ggplot2")
devtools::use_package("gridExtra")
devtools::use_testthat()

devtools::load_all("svComp", export_all=TRUE)
devtools::test("svComp")
devtools::install_deps(dependencies = TRUE)

R_DEFAULT_PACKAGES=NULL
parseNamespaceFile("svComp")
parseNamespaceFile()
loadNamespace("svComp")
devtools::create()
devtools::use_data_raw("svComp")
devtools::use_vignette("trio_sv_comparison")
devtools::use_vignette("bedNGS_smap_sv_comparison")
devtools::use_vignette("compare_2_bed_sv_puiMultiSV")

devcheck<-function(){
  setwd("/home/users/tliang/r_script/svRTools/project_rPackage/svComp") # Package root of svComp
  devtools::check() # run before building the R package with "R CMD build svComp"
}
rm(list=as.vector(lsf.str())) # Clear all functions

doc<-function(){
  setwd("/home/users/tliang/r_script/svRTools/project_rPackage/svComp") # Package root of svComp
  devtools::document()
}

library(devtools)
library(roxygen2)
if (.Platform$OS.type == "windows") {
  setwd("C://Users//tliang//Documents//win_projects//svRTools//project_rPackage//svComp")
  devtools::document()
  setwd("C://Users//tliang//Documents//win_projects//svRTools//project_rPackage")
  install("svComp")
} else {
  setwd("/home/users/tliang/r_script/svRTools/project_rPackage/svComp") # Package root of svComp
  devtools::document()
  setwd("/home/users/tliang/r_script/svRTools/project_rPackage")
  install("svComp")
}
library(svComp)

# Set bedtools path
Sys.setenv(PATH="/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin:/sbin:/bin:/home/users/csecol/software/external/bin:/home/users/csecol/software/external/bedtools2/bin")

# vnneuler, set JRE path
options(java.home="/usr/lib/jvm/java-7-openjdk-amd64/jre")
Sys.setenv(JAVA_HOME="/usr/lib/jvm/java-7-openjdk-amd64/jre")

# To see all the package in svComp
lsf.str("package::svComp")
