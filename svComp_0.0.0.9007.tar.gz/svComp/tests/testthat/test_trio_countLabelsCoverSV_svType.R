# Test trio_countLabelsCoverSV_svType

library(svComp)
library(dplyr)

rm(list=lsf.str()) # Remove all the overrided R functions

trio_test <- trio_indel(
  f_smap_ofs="/home/users/tliang/r_script/svRTools/project_rPackage/svComp/tests/NA12878_sm.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  minLen=0,
  minConf=3
)
f_smap_ofs="/home/users/tliang/r_script/svRTools/project_rPackage/svComp/tests/NA12878_sm.smap"
f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap"
f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap"
f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap"
f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap"
minLen=0
minConf=3

# SV 1.0 non-haplotype -sv wrapper
trio_nonhap_sv_con3 <- trio_indel(
  f_smap_ofs="/mnt/bionf_tmp/tliang/data/20160429_NA12878_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  minLen=0,
  minConf=3
)
project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_nonhapsv_con3_countLabels.txt")
write.table(trio_nonhap_sv_con3,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

trio_nonhap_sv_con0 <- trio_indel(
  f_smap_ofs="/mnt/bionf_tmp/tliang/data/20160429_NA12878_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160429_NA12891_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160429_NA12892_IrysV2.4/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  minLen=0,
  minConf=0
)
project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_nonhapsv_con0_countLabels.txt")
write.table(trio_nonhap_sv_con0,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

# Count SV by SV types
count_SV(trio_nonhap_sv_con3 %>% mutate(GenotypeGroup=-1))
# [1,] "deletion"  "475"
# [2,] "insertion" "982"
count_SV(trio_nonhap_sv_con3 %>% mutate(GenotypeGroup=-1) %>% filter(denovo==1))
# [1,] "deletion"  "92"
# [2,] "insertion" "110"
count_SV(trio_nonhap_sv_con3 %>% mutate(GenotypeGroup=-1) %>% filter(denovo==0))
# [1,] "deletion"  "383"
# [2,] "insertion" "872"



# Haplotype -refsplit Wrapper
trio_hap_refsplit_con3 <- trio_indel(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  minLen=0,
  minConf=3
)
count_SV(trio_hap_refsplit_con3 %>% mutate(Confidence=Confidence.smap))
project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_hapRefsplit_countLabels.txt")
write.table(trio_hap_refsplit_con3,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

trio_hap_refsplit_con0 <- trio_indel(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  minLen=0,
  minConf=0
)
project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_hapRefsplit_con0_countLabels.txt")
write.table(trio_hap_refsplit_con0,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

# Non-haplotype -sv
trio_del_nohap_refsplit <- trio_countLabelsCoverSV_svType(
  f_smap_ofs="/home/users/tliang/data/20151001_NA12878/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="deletion",
  minLen=0,
  minConf=3
)

trio_del_nohap_refsplit_nondenovo <- trio_countLabelsCoverSV_svType_nondenovo(
  f_smap_ofs="/home/users/tliang/data/20151001_NA12878/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="deletion",
  minLen=0,
  minConf=3
)
f_smap_ofs="/home/users/tliang/data/20151001_NA12878/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_dad="/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_mom="/home/users/tliang/data/20151001_NA12892/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
smap_girl <- readsmap(f_smap_ofs)
smap_dad <- readsmap(f_smap_dad)
smap_mom <- readsmap(f_smap_mom)
count_SV(smap_girl)
count_SV(smap_dad)
count_SV(smap_mom)

project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_del_nohapsv_countLabels.txt")
write.table(trio_del_nohap_refsplit,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

MoleOutputfile = paste0(project,"/ceph_del_nohapsv_countLabels_svOverlapSV1bp.txt")
write.table(trio_del_nohap_refsplit_nondenovo,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)


# haplotype -sv
trio_del_result <- trio_countLabelsCoverSV_svType(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="deletion",
  minLen=0,
  minConf=3
)


f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap"
f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap"
f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap"
f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap"
svType="deletion"
minLen=0
minConf=3


# haplotype -refsplit
trio_del_hap_refsplit <- trio_countLabelsCoverSV_svType(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="deletion",
  minLen=0,
  minConf=0
)

trio_del_hap_refsplit_nondenovo <- trio_countLabelsCoverSV_svType_nondenovo(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="deletion",
  minLen=0,
  minConf=0
)

trio_ins_hap_refsplit <- trio_countLabelsCoverSV_svType(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="insertion",
  minLen=0,
  minConf=0
)

trio_ins_hap_refsplit_nondenovo <- trio_countLabelsCoverSV_svType_nondenovo(
  f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
  f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
  f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
  svType="insertion",
  minLen=0,
  minConf=0
)

project="/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420"
MoleOutputfile = paste0(project,"/ceph_del_countLabelsAroundSV.txt")
write.table(trio_del_hap_refsplit,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

MoleOutputfile = paste0(project,"/ceph_del_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(trio_del_hap_refsplit_nondenovo,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

MoleOutputfile = paste0(project,"/ceph_ins_countLabelsAroundSV.txt")
write.table(trio_ins_hap_refsplit,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)

MoleOutputfile = paste0(project,"/ceph_ins_countLabelsAroundSV_svOverlapSV1bp.txt")
write.table(trio_ins_hap_refsplit_nondenovo,file=MoleOutputfile,quote=F,sep="\t",col.names=T,row.names=F)


f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap"
f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap"
f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap"
f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap"
svType="deletion"
minLen=0
minConf=0


# labels_trio <- trio_del_hap_refsplit
# labels_trio <- trio_del_result
labels_trio_has_coverage <- labels_trio %>% group_by(SmapEntryID) %>% filter(!any(is.na(n_alignedLabel_bf_sv))) #Filter out SV without parent GM coverage
nrow(labels_trio_has_coverage)
View(labels_trio_has_coverage)
minLabel_sv <- 5
labels_trio_more_labels_around <- labels_trio_has_coverage %>% filter(!any(n_alignedLabel_bf_sv < minLabel_sv | n_alignedLabel_af_sv < minLabel_sv)) # Filter out SV with less than 5 labels in franking region in parent GM
nrow(labels_trio_more_labels_around)
View(labels_trio_more_labels_around)
as.matrix(unique(labels_trio_more_labels_around %>% select(svSize.smap)))
plot(as.matrix(unique(labels_trio_more_labels_around %>% select(svSize.smap))))
plot(as.matrix(unique(labels_trio_more_labels_around %>% select(svSize.smap))),ylim=c(0,15000))
abline(h=2000,col="red")
length(unique(labels_trio$SmapEntryID))
length(unique(labels_trio_has_coverage$SmapEntryID))
length(unique(labels_trio_more_labels_around$SmapEntryID))

count_SV(smap_dad)
count_SV(smap_mom)
