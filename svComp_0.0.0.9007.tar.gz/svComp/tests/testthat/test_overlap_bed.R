# Compare SV between 2 samples
# bed1=NA12878_del_pui_20kb
# bed2=NA12878_del_all_con3
size_bin <- c(0, 500, 1000, 2000, 5000, 10000,15000,20000,30000,50000,70000,100000,150000,200000,300000,500000,1500000)
bin_names <- c("0-0.5","0.5-1","1-2","2-5","5-10","10-15","15-20","20-30","30-50","50-70","70-100","100-150","150-200","200-300","300-500","500+")

# Plot for sensitivity and SV size scatter plot
analyze_sensitivity_pui(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_all_con3,size_bin=size_bin,bin_names=bin_names)
analyze_sensitivity_pui(bed1=NA12878_ins_pui_20kb,bed2=NA12878_ins_all_con3,size_bin=size_bin,bin_names=bin_names)
analyze_sensitivity_pui(bed1=NA12891_del_pui_20kb,bed2=NA12891_del_all_con3,size_bin=size_bin,bin_names=bin_names)
analyze_sensitivity_pui(bed1=NA12891_ins_pui_20kb,bed2=NA12891_ins_all_con3,size_bin=size_bin,bin_names=bin_names)
analyze_sensitivity_pui(bed1=NA12892_del_pui_20kb,bed2=NA12892_del_all_con3,size_bin=size_bin,bin_names=bin_names)
analyze_sensitivity_pui(bed1=NA12892_ins_pui_20kb,bed2=NA12892_ins_all_con3,size_bin=size_bin,bin_names=bin_names)

analyze_sensitivity_pui <- function(bed1, bed2,size_bin,bin_names){
  bt_result1a <- bedTools(functionstring="intersect",bed1=bed1,bed2=bed2,optString="-wao")
  bt_result2a <- as.data.frame(add_names_bedintersect(bt_result1a))
  overlap_bed1 <- dplyr::filter(bt_result2a,matches!=0) # Get all the overlapped SVs (>=1bp) in Pui
  # overlap_bed1 <- overlap_bed1 %>% mutate(svratio = abs(pmin(a_score,b_score)/pmax(a_score, b_score))) %>% filter(svratio > 0.5) %>% nrow
  bed1_overlap <- overlap_bed1 %>% # make SV size value positive
    dplyr::mutate(a_score=abs(a_score),b_score=abs(b_score))

  bed1_overlap_wSize_unique <- bed1_overlap %>% # Filter: select matched SVs by SV ratio > 0.5, this will be our true positive set
    dplyr::mutate(svratio = pmin(a_score,b_score)/pmax(a_score, b_score)) %>%
    dplyr::filter(a_score > 0) %>%
    dplyr::filter(svratio > 0.5) %>%
    dplyr::select(1:5) %>%
    unique()
  bed1_all_wSize <- bed1 %>% dplyr::filter(svSize_med_filtByCv!=0) %>%
    dplyr::mutate(svSize_med_filtByCv = abs(svSize_med_filtByCv)) # Filter: Get all SVs that have a defined SV size (not 0), make positive.

  # Sensitivity barplot for overlap/all
  barplot_sensitivity(bedintersect_qry=bed1_overlap_wSize_unique$a_score,bedintersect_ref=bed1_all_wSize$svSize_med_filtByCv, size_bin=size_bin, bin_names=bin_names)

  # Make scatter plot for SV size compare for overlapped SVs
  scatterPlot_svSize(bed1_overlap,xlim=c(0,150000),ylim=c(0,150000))
}



# size_and_bin_overlap <- cbind(bed1_overlap_wSize$a_score,findInterval(bed1_overlap_wSize$a_score,size_bin))
# size_and_bin_all <- cbind(bed1_all_wSize$svSize_med_filtByCv,findInterval(bed1_all_wSize$svSize_med_filtByCv,size_bin))

# bedintersect_qry <- as.numeric(bed1_overlap_wSize$a_score)
# bedintersect_ref <- as.numeric(bed1_all_wSize$svSize_med_filtByCv)

overlap_bed1 <- dplyr::filter(bt_result2a,matches!=0) # Get all the overlapped SVs (>=1bp) in Pui
# overlap_bed1 <- overlap_bed1 %>% mutate(svratio = abs(pmin(a_score,b_score)/pmax(a_score, b_score))) %>% filter(svratio > 0.5) %>% nrow
bed1_overlap <- overlap_bed1 %>% # make SV size value positive
  dplyr::mutate(a_score=abs(a_score),b_score=abs(b_score))

bed1_overlap_wSize_unique <- bed1_overlap %>% # Filter: select matched SVs by SV ratio > 0.5, this will be our true positive set
  dplyr::mutate(svratio = pmin(a_score,b_score)/pmax(a_score, b_score)) %>%
  dplyr::filter(a_score > 0) %>%
  dplyr::filter(svratio > 0.5) %>%
  dplyr::select(1:5) %>%
  unique()
bed1_all_wSize <- bed1 %>% dplyr::filter(svSize_med_filtByCv!=0) %>%
  dplyr::mutate(svSize_med_filtByCv = abs(svSize_med_filtByCv)) # Filter: Get all SVs that have a defined SV size (not 0), make positive.

result2 <- overlap_bed(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_all_con3)

# filter_sizeZero_svRatio_BNG_bedintersect <- function(bedintersect_df){
#   new_bed <- bedintersect_df %>%
#     mutate(a_score=abs(a_score),b_score=abs(b_score)) %>%
#     mutate(svratio = abs(pmin(a_score,b_score)/pmax(a_score, b_score))) %>%
#     dplyr::filter(a_score > 0) %>%
#     filter(svratio > 0.5) %>%
#     select(1:5) %>%
#     unique()
#   return(new_bed)
# }

# filter_sizeZero_Pui <- function(bed_pui) {
#   names(bed_pui) <- c("chr", "start", "end", "id", "svSize")
#   new_bed <- bed_pui %>% dplyr::filter(svSize!=0) %>%
#     dplyr::mutate(svSize = abs(svSize))
#
# #   new_bed <- bed_pui %>% dplyr::filter(svSize_med_filtByCv!=0) %>%
# #     dplyr::mutate(svSize_med_filtByCv = abs(svSize_med_filtByCv))
#   return(new_bed)
# }

# overlap_bed <- function(bed1, bed2) {
#   bt_result1a <- bedTools(functionstring="intersect",bed1=bed1,bed2=bed2,optString="-wao") # Overlap by 1bp
#   bt_result2a <- as.data.frame(add_names_bedintersect(bt_result1a))
#   bed_overlap_bed1 <- dplyr::filter(bt_result2a,matches!=0) # Collect the overlapped SV in bed1
#   bed1_overlap_wSize_unique_count <- filter_sizeZero_svRatio_BNG_bedintersect(bed_overlap_bed1) %>% nrow
#   bed1_all_wSize_count <- filter_sizeZero_Pui(bed1) %>% nrow # Filter: Get all SVs that have a defined SV size (not 0), make positive.
#
#   overlap_bed1 <- bed1_overlap_wSize_unique_count
#   overlap_percent_bed1 <- overlap_bed1 / bed1_all_wSize_count
#   bed1_unique_wSize <- bed1_all_wSize_count - overlap_bed1
#   nonoverlap_percent_bed1 <- bed1_unique_wSize / bed1_all_wSize_count
#   bed1a <- c(percent(overlap_percent_bed1,digits=1),overlap_bed1, percent(nonoverlap_percent_bed1,digits=1),bed1_unique_wSize, total_bed1)
#
#
#   bt_result1b <- bedTools(functionstring="intersect",bed1=bed2,bed2=bed1,optString="-wao")
#   bt_result2b <- as.data.frame(add_names_bedintersect(bt_result1b))
#   bed_overlap_bed2 <- dplyr::filter(bt_result2b,matches!=0) # Collect the overlapped SV in bed2
#   bed2_overlap_wSize_unique_count <- filter_sizeZero_svRatio_BNG_bedintersect(bed_overlap_bed2) %>% nrow
#   bed2_all_wSize_count <- filter_sizeZero_Pui(bed2) %>% nrow # Filter: Get all SVs that have a defined SV size (not 0), make positive.
#
#   overlap_bed2 <- bed2_overlap_wSize_unique_count
#   overlap_percent_bed2 <- overlap_bed2 / bed2_all_wSize_count
#   bed2_unique_wSize <- bed2_all_wSize_count - overlap_bed2
#   nonoverlap_percent_bed2 <- bed2_unique_wSize / bed2_all_wSize_count
#   bed1b <- c(percent(overlap_percent_bed2,digits=1),overlap_bed2, percent(nonoverlap_percent_bed2,digits=1),bed2_unique_wSize, total_bed2)
#
#   count_overlap <- rbind(bed1a,bed1b)
#   return(count_overlap)
# }

trio_del_hap_refsplit %>% mutate(name=paste0(SmapEntryID,'_',GenotypeGroup)) %>% select(RefcontigID, RefStartPos.smap, RefEndPos.smap,name,svSize.smap) %>% unique %>% head
trio_del_hap_refsplit %>% mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>% select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>% unique %>% nrow


# Pui's
## Deletion
pui_del <- read.table(file="/home/users/tliang/linux_projects/20160413_CEPH_Pui/pui_paper/Supplementary_2_Table1_deletion_svSize.txt",header = TRUE,sep="\t",dec=".",fill = TRUE, comment.char = "")
NA12878_del_pui <- pui_del %>% filter(grepl("del",NA12878)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12878_del_pui$svSize_med_filtByCv[is.na(NA12878_del_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12878_del_pui_20kb <- add_buffer(NA12878_del_pui,buffer=20000)

NA12891_del_pui <- pui_del %>% filter(grepl("del",NA12891)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12891_del_pui$svSize_med_filtByCv[is.na(NA12891_del_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12891_del_pui_20kb <- add_buffer(NA12891_del_pui,buffer=20000)

NA12892_del_pui <- pui_del %>% filter(grepl("del",NA12892)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12892_del_pui$svSize_med_filtByCv[is.na(NA12892_del_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12892_del_pui_20kb <- add_buffer(NA12892_del_pui,buffer=20000)

## Insertion
pui_ins <- read.table(file="/home/users/tliang/linux_projects/20160413_CEPH_Pui/pui_paper/Supplementary_3_Table2_insertion_svSize.txt",header = TRUE,sep="\t",dec=".",fill = TRUE, comment.char = "")
NA12878_ins_pui <- pui_ins %>% filter(grepl("ins",NA12878)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12878_ins_pui$svSize_med_filtByCv[is.na(NA12878_ins_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12878_ins_pui_20kb <- add_buffer(NA12878_ins_pui,buffer=20000)

NA12891_ins_pui <- pui_ins %>% filter(grepl("ins",NA12891)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12891_ins_pui$svSize_med_filtByCv[is.na(NA12891_ins_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12891_ins_pui_20kb <- add_buffer(NA12891_ins_pui,buffer=20000)

NA12892_ins_pui <- pui_ins %>% filter(grepl("ins",NA12892)) %>%
  mutate(id=paste0(chr,"_",start,"_",stop,"_",mendelian)) %>%
  select(1:3,id,svSize_med_filtByCv)
NA12892_ins_pui$svSize_med_filtByCv[is.na(NA12892_ins_pui$svSize_med_filtByCv)] <- 0 # replace all NA in "svSize_med_filtByCv" to be zero, to make use of all SV, w/ or w/out SV size
NA12892_ins_pui_20kb <- add_buffer(NA12892_ins_pui,buffer=20000)

# daughter with no SV overlap with either parent for >= 1bp, no filter
NA12878_del_nonoverlaped <- trio_del_hap_refsplit %>% mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>% select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>% unique
NA12878_del_overlaped <- trio_del_hap_refsplit_nondenovo %>% mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>% select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>% unique
NA12878_del_all <- rbind(NA12878_del_nonoverlaped,NA12878_del_all)
result <- overlap_bed(bed1=NA12878_del_pui,bed2=NA12878_del_all)
result <- overlap_bed(bed1=NA12878_del_pui,bed2=NA12878_del_overlaped) # 85% overlap

result <- overlap_bed(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_overlaped)# 86% overlap

# Deletion: daughter with no SV overlap with either parent for >= 1bp, Confidence > 3
NA12878_del_nonoverlaped_con3 <- trio_del_hap_refsplit %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>%
  filter(Confidence.smap > 3) %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique
NA12878_del_overlaped_con3 <- trio_del_hap_refsplit_nondenovo %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),GenotypeGroup)) %>%
  filter(Confidence.smap > 3) %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique
NA12878_del_all_con3 <- rbind(NA12878_del_nonoverlaped_con3,NA12878_del_overlaped_con3)
result1 <- overlap_bed(bed1=NA12878_del_pui,bed2=NA12878_del_all_con3)
result1 <- overlap_bed(bed1=NA12878_del_pui,bed2=NA12878_del_overlaped_con3)
result1 <- overlap_bed(bed1=NA12878_del_pui,bed2=NA12878_del_nonoverlaped_con3)

result2 <- overlap_bed_svSizeRatio(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_all_con3)# Add 2kb buffer
overlap_summary <- as.data.frame(result2[1])
bed1_overlapped <- as.data.frame(result2[2])
bed2_overlapped <- as.data.frame(result2[3])
bed1_unique <- as.data.frame(result2[4])
bed2_unique <- as.data.frame(result2[5])

result3 <- overlap_bed(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_overlaped_con3)
result4 <- overlap_bed(bed1=NA12878_del_pui_20kb,bed2=NA12878_del_nonoverlaped_con3)

# Insertion: daughter with no SV overlap with either parent for >= 1bp, Confidence > 3
NA12878_ins_nonoverlaped_con3 <- trio_ins_hap_refsplit %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence.smap > 3) %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique
NA12878_ins_overlaped_con3 <- trio_ins_hap_refsplit_nondenovo %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence.smap > 3) %>%
  select(RefcontigID, RefStartPos.smap, RefEndPos.smap,groups,svSize.smap) %>%
  unique
NA12878_ins_all_con3 <- rbind(NA12878_ins_nonoverlaped_con3,NA12878_ins_overlaped_con3)
result1 <- overlap_bed(bed1=NA12878_ins_pui,bed2=NA12878_ins_all_con3)
result1 <- overlap_bed(bed1=NA12878_ins_pui,bed2=NA12878_ins_overlaped_con3)
result1 <- overlap_bed(bed1=NA12878_ins_pui,bed2=NA12878_ins_nonoverlaped_con3)

result2 <- overlap_bed(bed1=NA12878_ins_pui_20kb,bed2=NA12878_ins_all_con3)# Add 2kb buffer, 86% overlap
result2 <- overlap_bed(bed1=NA12878_ins_pui_20kb,bed2=NA12878_ins_overlaped_con3)
result2 <- overlap_bed(bed1=NA12878_ins_pui_20kb,bed2=NA12878_v_nonoverlaped_con3)

test <- rbind(NA12878_del_all_con3,NA12878_ins_all_con3)
result1 <- overlap_bed(bed1=NA12878_del_pui,bed2=test)

# Father SV
minLen=0
minConf=3
svType="deletion"
f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap"
smap_dad<- readsmap(f_smap_dad)
smap_dad_del <- get_sv_type_minlen(smap_dad,svType)
NA12891_del_all_con3 <- smap_dad_del %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence > minConf) %>%
  select(RefcontigID1, RefStartPos, RefEndPos,groups,svSize) %>%
  unique
result1 <- overlap_bed(bed1=NA12891_del_pui,bed2=NA12891_del_all_con3)
result2 <- overlap_bed(bed1=NA12891_del_pui_20kb,bed2=NA12891_del_all_con3)# Add 2kb buffer

svType="insertion"
smap_dad_ins <- get_sv_type_minlen(smap_dad,svType)
NA12891_ins_all_con3 <- smap_dad_ins %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence > minConf) %>%
  select(RefcontigID1, RefStartPos, RefEndPos,groups,svSize) %>%
  unique
result1 <- overlap_bed(bed1=NA12891_ins_pui,bed2=NA12891_ins_all_con3)
result2 <- overlap_bed(bed1=NA12891_ins_pui_20kb,bed2=NA12891_ins_all_con3)# Add 2kb buffer

# Mother SV
result1 = c()
result2=c()
smap_mom<- readsmap(f_smap_mom)
smap_mom_del <- get_sv_type_minlen(smap_mom,svType)
NA12892_del_all_con3 <- smap_dad_del %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence > minConf) %>%
  select(RefcontigID1, RefStartPos, RefEndPos,groups,svSize) %>%
  unique
result1 <- overlap_bed(bed1=NA12892_del_pui,bed2=NA12892_del_all_con3)
result2 <- overlap_bed(bed1=NA12892_del_pui_20kb,bed2=NA12892_del_all_con3)# Add 2kb buffer

svType="insertion"
smap_mom_ins <- get_sv_type_minlen(smap_mom,svType)
NA12892_ins_all_con3 <- smap_dad_ins %>%
  mutate(groups=ifelse(GenotypeGroup<0,paste0('s',SmapEntryID),paste0('g',GenotypeGroup))) %>%
  filter(Confidence > minConf) %>%
  select(RefcontigID1, RefStartPos, RefEndPos,groups,svSize) %>%
  unique
result1 <- overlap_bed(bed1=NA12892_ins_pui,bed2=NA12892_ins_all_con3)
result2 <- overlap_bed(bed1=NA12892_ins_pui_20kb,bed2=NA12892_ins_all_con3)# Add 2kb buffer

# SV sensitivity by SV size stratification (Sensitivity = Number of Daughter SV found in parents/total Daughter SV)
size_bin <- c(4000,10000)
intervals_data <- findInterval(bed1_overlap_wSize,size_bin)
NA12878_del_overlaped_con3

# Mutiple contigs from one bed file is overlapping with a contig in another bed file. Let's count how many contigs are overlapped.
bed_overlap_bed1  %>% mutate(a_score=abs(a_score), b_score=abs(b_score), pmin=pmin(a_score,b_score), pmax=pmax(a_score, b_score), svratio=(abs(pmin/pmax)), a_first_r = abs(a_score)/abs(b_score)) %>% filter(matches!=0, a_score>0, b_score>0, a_first_r<2 & a_first_r>0.5) %>% select(1:5) %>% dplyr::count(a_id) %>% select(n) %>% count()
bed_overlap_bed2  %>% mutate(a_score=abs(a_score), b_score=abs(b_score), pmin=pmin(a_score,b_score), pmax=pmax(a_score, b_score), svratio=(abs(pmin/pmax)), a_first_r = abs(a_score)/abs(b_score)) %>% filter(matches!=0, a_score>0, b_score>0, a_first_r<2 & a_first_r>0.5) %>% select(1:5) %>% dplyr::count(a_id) %>% select(n) %>% count()
