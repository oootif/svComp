# Project: scComp_ideogram

library(shiny)
library(dplyr)
library(svComp)
library(shinythemes)
library(quantsmooth)

version<- 1



ui<-fluidPage(theme = shinytheme("cerulean"),
  fluidRow(
    # column(4,h1("SV Ideogram"),tags$head(tags$link(rel="icon", type="image/png", href="/favicon-16x16.png", sizes="16x16"))),
    column(4,h1("SV Ideogram")),
    column(6,checkboxInput(inputId="show_help",label="With a little help from my friend",value=FALSE),
           htmlOutput(outputId = "help_version")
    ),
    column(2,div(img(height=50,width=130,src="bionanogenomics_logo.JPG"), class="logo"))
  ),  # End of fluidRow

  wellPanel(
    fluidRow( # total 12 units in a row
      column(3,h3("SV File 1"),
        fileInput(inputId = "smap1",
          label="Method1: Upload SMAP file 1 (local)"
        )
      ),
      column(9,
        textInput(inputId="smap1path",
          label="Method2: Path to SMAP file 1 (server)",
          # placeholder = "/home/users/tliang/data/20151001_NA12878/output/contigs/exp_refineFinal1_sv_RefSplit20151103/NA12878ml.smap",
          value = NULL,
          width = '100%'
        ),
        fluidRow(
          column(2,h5("Sample data:")),
          column(7,
                 checkboxInput(inputId = "smap1_sample",
                               label = "Use NA12878 SMAP file (hg38, Wilson ran on 20160718)",value = FALSE)
          )
        )
      )  # End of column
    ) # End of fluidRow
  ), # End of wellPanel

  fluidRow(
    sidebarLayout(
      sidebarPanel(width = 3,h4("Stratified SV size comparison"),
        # htmlOutput(outputId = "help_stratify"),
        numericInput(inputId = "minLen",min = 0,max=100,value = 0, label="Minimum length threshold (kb)"),
        numericInput(inputId = "minConf",min = -2,max=10,value = -2, label="Minimum raw confidence threshold"),
        checkboxInput(inputId = "show_trans",label="Show Translocations",value=FALSE),
        checkboxInput(inputId = "show_del",label="Show Deletions",value=FALSE),
        checkboxInput(inputId = "show_ins",label="Show Insertions",value=FALSE),
        actionButton(inputId = "run_svComp",label="Show SV")
      ), # end of sidebarPanel
      mainPanel(width = 9,
                plotOutput("ideogram")
      ) # end of mainPanel
    ) # end of sidebarLayout
  ) # End of fluidRow
) # End of fluidPage


server <- function(input,output,session){
  observe({
    if(!is.null(input$smap1)){
      updateCheckboxInput(session, "smap1_sample",value = FALSE)
      updateTextInput(session, "smap1path",
                      value = ""
      )
    }
    })


  observe({
    if(input$smap1_sample){
      path1 <- "/home/users/wrodriguez/exp_refineFinal1_merged_filter_inversions.smap"
    } else{
      path1 <- ""
    }
    updateTextInput(session, "smap1path",
                    value = path1
    )
  })

  # reactive object/expression: save result in memory
  v <- reactiveValues(
    minLen=0, # Unit is kb
    minConf=0
  )
  v1 <- reactiveValues(
    smap1path=NULL
  )


  # beds <- reactive({
  beds <- eventReactive(input$run_svComp,{
    # req(input$smap1path != "" | input$bed1path_del !="" | !is.null(input$smap1))
    # validate(
    #   need(!is.null(input$smap1path), message = "Please select SMAP file 1"),
    #   need(!is.null(input$smap2path), message = "Please select SMAP file 2")
    # )

    v$minConf <- input$minConf
    v$minLen <- input$minLen * 1000

    # Print working message while processing
    withProgress({
      setProgress(message = "Processing SV overlap...")

      # Read smap1/beds into bed dataframe
      if(!is.null(input$smap1)){
        if (is.null(v1$smap1path) || input$smap1$datapath != v1$smap1path){
          v1$smap1path <- input$smap1$datapath
          v1$smap1<-readsmap(v1$smap1path)
        }

        # Deletion
        smap_del1 <- get_sv_type_minlen(v1$smap1,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del1 <- select(smap_del1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins1 <- get_sv_type_minlen(v1$smap1,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins1 <- select(smap_ins1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

        # Translocation
        buffer_trans <- 1000
        smap_transInter1 <- get_sv_type_minlen(v1$smap1,svType="translocation_interchr",minLen=0, minConf=-2)
        bed_transInter1 <- mutate(smap_transInter1, name=SmapEntryID,chr=RefcontigID1, start=RefStartPos-buffer_trans,end=RefStartPos+buffer_trans,score=1) %>%
          select(chr, start, end, name, score)
        smap_transIntra1 <- get_sv_type_minlen(v1$smap1,svType="translocation_intrachr",minLen=0, minConf=-2)
        bed_transIntra1 <- mutate(smap_transIntra1, name=SmapEntryID,chr=RefcontigID1, start=RefStartPos-buffer_trans,end=RefStartPos+buffer_trans,score=1) %>%
          select(chr, start, end, name, score)

      } else if(!is.null(input$smap1path) & input$smap1path != ""){
        if (is.null(v1$smap1path) || input$smap1path != v1$smap1path) {
          v1$smap1path <- input$smap1path
          v1$smap1<-readsmap(v1$smap1path)
        }

        # Deletion
        smap_del1 <- get_sv_type_minlen(v1$smap1,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del1 <- select(smap_del1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins1 <- get_sv_type_minlen(v1$smap1,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins1 <- select(smap_ins1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

        # Translocation
        buffer_trans <- 1000
        smap_transInter1 <- get_sv_type_minlen(v1$smap1,svType="translocation_interchr",minLen=0, minConf=-2)
        bed_transInter1 <- dplyr::mutate(smap_transInter1, name=SmapEntryID,chr=RefcontigID1, start=RefStartPos-buffer_trans,end=RefStartPos+buffer_trans,score=1) %>%
          dplyr::select(chr, start, end, name, score)
        smap_transIntra1 <- get_sv_type_minlen(v1$smap1,svType="translocation_intrachr",minLen=0, minConf=-2)
        bed_transIntra1 <- dplyr::mutate(smap_transIntra1, name=SmapEntryID,chr=RefcontigID1, start=RefStartPos-buffer_trans,end=RefStartPos+buffer_trans,score=1) %>%
          dplyr::select(chr, start, end, name, score)
      } else {
        print("weird......")
      }
      # print(head(smap_transInter1))
      # print(bed_transInter1)
      # print(class(bed_transInter1))
      result <- list(bed_transInter1,bed_transIntra1)
      # print(class(result))
    })
    return(result)
  })
#
#   buffer=1 #1 #Check buffer around the translocation breakpoint. Need to be >=1 for pairtopair to work
#   bed_sampleBkptA2 <- ctl_trans_tidy %>%
#     mutate(samplebkpt=paste(sampleName,smapId,sep="_")) %>%
#     #   mutate(name=paste0(samplebkpt,"_A"),chr=chrA, start=bkptA-buffer, end=bkptA+buffer, score=1) %>%
#     mutate(name=samplebkpt,chr=chrA, start=bkptA-buffer, end=bkptA+buffer, score=1) %>%
#     select(chr,start,end,name,score)
#
  # Translocation to smap
  # pad<-10000 # Maximum 100000?
  # hg19_size <- "/home/users/csecol/genomes/human/hg19/human.hg19.genome"
  # result_slop1 <-bedTools_multi(functionstring = "slop",bed_list = list(bedpe_common4 %>% select(1:3)),optString = paste0("-g ",hg19_size," -b ",pad),sort=FALSE)
  # result_slop2 <-bedTools_multi(functionstring = "slop",bed_list = list(bedpe_common4 %>% select(4:6)),optString = paste0("-g ",hg19_size," -b ",pad),sort=FALSE)
  # rcircos_data <- cbind(result_slop1,result_slop2,bedpe_common4[,7])
  #

  # plot Ideogram
  # plot_ideogram_bed(list(bed_sampleBkptA2),"testing","red")
  # plot_ideogram_bed(list(bed_sampleBkptA2,bed_sampleBkptB2),"testing","red") # plot both break points

  # Plot Ideogram
  output$ideogram <- renderPlot({

    # browser()
    # print(head(beds()[[1]]))
    # print(class(beds()))
    # print(class(beds()[[1]]))

    plot_ideogram_bed(beds(),"Translocations",c("red","blue")) # red is Inter-trans, blue is Intra-trans

  })

}

shinyApp(ui = ui,server=server)
