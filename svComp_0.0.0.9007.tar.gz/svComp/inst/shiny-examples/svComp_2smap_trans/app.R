library(shiny)
library(dplyr)
library(svComp)
library(shinythemes)

version<- 18

intersect_bed <- function(bed1,bed2,svratio_threshold=0.5){
  optString <- "-wao"
  svratio_threshold <- svratio_threshold
  colnames(bed1) <- c("chr","start","end","id","svSize")
  bt_result1a <- bedTools(functionstring="intersect",bed1=bed1,bed2=bed2,optString=optString)

  bt_result2a <- as.data.frame(add_names_bedintersect(bt_result1a))
  overlap_bed1 <- dplyr::filter(bt_result2a,matches!=0) # Get all the overlapped SVs (>=1bp) in Pui
  bed1_overlap <- overlap_bed1 %>% # make SV size value positive
    dplyr::mutate(a_score=abs(a_score),b_score=abs(b_score))

  bed1_overlap_wSize_unique <- filter_sizeZero_svRatio_BNG_bedintersect(bed1_overlap,svratio_threshold=svratio_threshold)

  bed1_unique <- bed1 %>% filter(!id %in% bed1_overlap_wSize_unique$a_id)
  bed1_overlap_svratioThres <- bed1 %>% filter(id %in% bed1_overlap_wSize_unique$a_id)
  result <- list(bed1_overlap_wSize_unique$a_score, bed1$svSize, bed1_overlap, bed1_overlap_svratioThres, bed1_unique)
  return(result)
}

ui<-fluidPage(theme = shinytheme("cerulean"),
  fluidRow(
    # column(4,h1("SV Comparison"),tags$head(tags$link(rel="icon", type="image/png", href="/favicon-16x16.png", sizes="16x16"))),
    column(4,h1("SV Comparison")),
    column(6,checkboxInput(inputId="show_help",label="With a little help from my friend",value=FALSE),
           htmlOutput(outputId = "help_version")
    ),
    column(2,div(img(height=50,width=130,src="bionanogenomics_logo.JPG"), class="logo"))
  ),  # End of fluidRow

  wellPanel(
    fluidRow( # total 12 units in a row
      column(3,h3("SV File 1"),
        fileInput(inputId = "smap1",
          label="Method1: Upload SMAP file 1 (local)"
        ),
        htmlOutput(outputId = "help_input")
        # div(img(height=230,width=300,src="sensitivity_definition.PNG"), class="logo")
      ),
      column(9,
        textInput(inputId="smap1path",
          label="Method2: Path to SMAP file 1 (server)",
          # placeholder = "/home/users/tliang/data/20151001_NA12878/output/contigs/exp_refineFinal1_sv_RefSplit20151103/NA12878ml.smap",
          value = NULL,
          width = '100%'
        ),

        hr(),
        h5("OR Method3:"),
        textInput(inputId="bed1path_del",
          label="Path to deletion BED file 1 (server)",
          # placeholder = "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_del_noZero_zyg.bed",
          value = NULL,
          width = '100%'
        ),
        textInput(inputId="bed1path_ins",
          label="and Path to insertion BED file 1 (server)",
          # placeholder = "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_ins_noZero_zyg.bed",
          value = NULL,
          width = '100%'
        ),
        htmlOutput(outputId = "help_bed_format"),
        fluidRow(
          column(2,h5("Sample data:")),
          column(7,
            checkboxInput(inputId = "smap1_sample",
                          label = "Use NA12891 SMAP file (hg38)",value = FALSE),
            checkboxInput(inputId = "pui_sample",
                          label = "Use NA12878 BED files (hg38, Mak et al.)",value = FALSE)
          )
        )
      )  # End of column
    ) # End of fluidRow
  ), # End of wellPanel
  wellPanel(
    fluidRow(
      column(3,h3("SV File 2"),
        fileInput(inputId="smap2",
                 label="Method1: Upload SMAP file 2 (local)"
        ),
        h5("Method4: "),
        fileInput(inputId="bed2_del",
                 label="Upload deletion BED file 2 (local)"
        ),
        fileInput(inputId="bed2_ins",
                 label="and Upload insertion BED file 2 (local)"
        )
      ),
      column(9,
        textInput(inputId="smap2path",
                 label="Method2: Path to SMAP file 2 (server)",
                 # placeholder = "/home/users/tliang/data/20151001_NA12891/output/contigs/exp_refineFinal1_sv_RefSplit20151103/NA12891ml.smap",
                 value = NULL,
                 width = '100%'
        ),

        hr(),
        h5("OR Method3: "),
        textInput(inputId="bed2path_del",
                 label="Path to deletion BED file 2 (server)",
                 # placeholder = "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_del_noZero_zyg.bed",
                 value = NULL,
                 width = '100%'
        ),
        textInput(inputId="bed2path_ins",
                 label="and Path to insertion BED file 2 (server)",
                 # placeholder = "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_ins_noZero_zyg.bed",
                 value = NULL,
                 width = '100%'
        ),
        fluidRow(
         column(2,h5("Sample data:")),
         column(7,
                checkboxInput(inputId = "smap2_sample",
                              label = "Use NA12878 SMAP file (hg38)",value = FALSE)
         )
        )
      ) # end of column
    ) # End of fluidRow
  ), # End of wellPanel
  fluidRow(
    sidebarLayout(
      sidebarPanel(width = 3,h4("Stratified SV size comparison"),
        htmlOutput(outputId = "help_stratify"),
        numericInput(inputId = "minLen",min = 0,max=100,value = 0, label="Minimum length threshold (kb)"),
        numericInput(inputId = "minConf",min = 0,max=10,value = 3, label="Minimum raw confidence threshold"),
        numericInput(inputId = "buffer",min = 0,max=100,value = 20, label="Buffer (kb)"),
        sliderInput(inputId = "svratio_threshold",min = 0,max=1, value = 0.5, step = 0.05, label="SV size ratio threshold"),
        radioButtons(inputId = "sizebin",label="Bins for histogram",
                    choices = c("0-0.5-1-2-5-10-15-20-30-50-70-100-150-200-300-500-inf kb"=1,
                                "0-0.5-1-2-5-10-20-100-inf kb"=2),
                    selected = 1,
                    width = '100%'),
        actionButton(inputId = "run_svComp",label="Run comparison"),
        checkboxInput(inputId = "show_unique_bed",label="Show unique SVs",value=FALSE)
      ), # end of sidebarPanel
      mainPanel(width = 9,
        tabsetPanel(type="tabs",
          tabPanel("File-1 based",
            column(6,h4("Deletions",align ="center"),
              plotOutput("hist"),
              verbatimTextOutput('stats'),
              downloadButton(outputId = 'download_unique_bed1', label = 'Download file-1 unique deletions in BED'),
              downloadButton(outputId = 'download_overlap_bed1', label = 'Download file-1 overlapped deletions in BED'),
              tableOutput('unique_bed')
            ),
            column(6,h4("Insertions",align ="center"),
              plotOutput("hist2"),
              verbatimTextOutput('stats2'),
              downloadButton(outputId = 'download_unique_bed2', label = 'Download file-1 unique insertions in BED'),
              downloadButton(outputId = 'download_overlap_bed2', label = 'Download file-1 overlapped insertions in BED'),
              tableOutput('unique_bed2')
            )
          ), # end of tabPanel
          tabPanel("File-2 based",
            column(6,h4("Deletions",align ="center"),
              plotOutput("hist3"),
              verbatimTextOutput('stats3'),
              downloadButton(outputId = 'download_unique_bed3', label = 'Download file-2 unique deletions in BED'),
              downloadButton(outputId = 'download_overlap_bed3', label = 'Download file-2 overlapped deletions in BED'),
              tableOutput('unique_bed3')
            ),
            column(6,h4("Insertions",align ="center"),
              plotOutput("hist4"),
              verbatimTextOutput('stats4'),
              downloadButton(outputId = 'download_unique_bed4', label = 'Download file-2 unique insertions in BED'),
              downloadButton(outputId = 'download_overlap_bed4', label = 'Download file-2 overlapped insertions in BED'),
              tableOutput('unique_bed4')
            )
          ) # end of tabPanel
        ) # end of tabsetPanel
      ) # end of mainPanel
    ) # end of sidebarLayout
  ), # End of fluidRow
  fluidRow(
    sidebarLayout(
      sidebarPanel(width = 3,h4("Size comparison for overlapped SV"),
        sliderInput(inputId = "xlim",label="Set scatter plot x-range",min = 0,max = 1000000,value = c(0,150000)),
        h5("* region between red lines indicates SV size within 50% reciprocal difference"),
        htmlOutput(outputId = "help_scatter_plot"),
        br(),
        textInput(inputId = "bed1name",value = "file-1 SV size (bp)",placeholder = "file-1 SV size (bp)",label = "Set x-axis name"),
        textInput(inputId = "bed2name",value = "file-2 SV size (bp)",placeholder = "file-2 SV size (bp)",label = "Set y-axis name")
      ),
      mainPanel(width = 9,
        column(6,h4("Deletion",align ="center"),
               plotOutput("svSize_distribution_del", width="400px",height = "400px")
        ),
        column(6,h4("Insertion",align ="center"),
               plotOutput("svSize_distribution_ins", width="400px",height = "400px")
        )
      ) # end of mainPanel
    ) # end of sidebarLayout
  ) # End of fluidRow
) # End of fluidPage


server <- function(input,output,session){
  observe({
    if(!is.null(input$smap1)){
      updateCheckboxInput(session, "smap1_sample",value = FALSE)
      updateCheckboxInput(session, "pui_sample",value = FALSE)
      updateTextInput(session, "smap1path",
                      value = ""
      )
      updateTextInput(session, "bed1path_del",
                      value = ""
      )
      updateTextInput(session, "bed1path_ins",
                      value = ""
      )
    }
    })
  observe({
    if(!is.null(input$smap2)){
      updateCheckboxInput(session, "smap2_sample",value = FALSE)
      updateTextInput(session, "smap2path",
                      value = ""
      )
      updateTextInput(session, "bed2path_del",
                      value = ""
      )
      updateTextInput(session, "bed2path_ins",
                      value = ""
      )
    }
  })

  observe({
    if(input$smap1_sample){
      path1 <- "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/NA12891_haprefsplit_homocollapsed.smap"
    } else{
      path1 <- ""
    }
    updateCheckboxInput(session, "pui_sample",value = FALSE)
    updateTextInput(session, "smap1path",
                    value = path1
    )
    updateTextInput(session, "bed1path_del",
                    value = ""
    )
    updateTextInput(session, "bed1path_ins",
                    value = ""
    )
  })
  observe({
    # We'll use these multiple times, so use short var names for
    # convenience.
    if(input$pui_sample){
      path1_del <- "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_del_noZero_zyg.bed"
      path1_ins <- "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/pui_NA12878_ins_noZero_zyg.bed"
    } else{
      path1_del <- ""
      path1_ins <- ""
    }
    updateCheckboxInput(session, "smap1_sample",value = FALSE)
    updateTextInput(session, "bed1path_del",
                    value = path1_del
    )
    updateTextInput(session, "bed1path_ins",
                    value = path1_ins
    )
    updateTextInput(session, "smap1path",
                    value = ""
    )
  })


  observe({
    if(input$smap2_sample){
      path2 <- "/home/users/tliang/linux_projects/20160413_CEPH_Pui/20160420/NA12878_haprefsplit_homocollapsed.smap"
    } else{
      path2 <- ""
    }
    updateTextInput(session, "smap2path",
                    value = path2
    )
  })


  # reactive object/expression: save result in memory
  v <- reactiveValues(
    minLen=0, # Unit is kb
    minConf=0,
    buffer=0,
    sizebin=0,
    svratio_threshold=0
  )
  v1 <- reactiveValues(
    smap1path=NULL,
    smap2path=NULL

  )
  v2 <- reactiveValues(
    xlim=c(0,150000),
    bed1name=NULL,
    bed2name=NULL
  )

  # beds <- reactive({
  beds <- eventReactive(input$run_svComp,{
    # req(input$smap1path != "" | input$bed1path_del !="" | !is.null(input$smap1))
    # validate(
    #   need(!is.null(input$smap1path), message = "Please select SMAP file 1"),
    #   need(!is.null(input$smap2path), message = "Please select SMAP file 2")
    # )

    v$minConf <- input$minConf
    v$minLen <- input$minLen * 1000
    v$buffer <- input$buffer * 1000
    v$sizebin <- input$sizebin
    v$svratio_threshold <- input$svratio_threshold
    if (v$sizebin == 1){
      v$size_bin <- c(0, 500, 1000, 2000, 5000, 10000,15000,20000,30000,50000,70000,100000,150000,200000,300000,500000,100000000)
      v$bin_names <- c("0-0.5","0.5-1","1-2","2-5","5-10","10-15","15-20","20-30","30-50","50-70","70-100","100-150","150-200","200-300","300-500","500+")
    } else if (v$sizebin ==2){
      v$size_bin <- c(0, 500, 1000, 2000, 5000, 10000,20000,100000,100000000)
      v$bin_names <- c("0-0.5","0.5-1","1-2","2-5","5-10","10-20","20-100","100+")
    }

    # Print working message while processing
    withProgress({
      setProgress(message = "Processing SV overlap...")

      # Read smap1/beds into bed dataframe
      if(!is.null(input$smap1)){
        if (is.null(v1$smap1path) || input$smap1$datapath != v1$smap1path){
          v1$smap1path <- input$smap1$datapath
          v1$smap1<-readsmap(v1$smap1path)
        }

        # Deletion
        smap_del1 <- get_sv_type_minlen(v1$smap1,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del1 <- select(smap_del1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins1 <- get_sv_type_minlen(v1$smap1,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins1 <- select(smap_ins1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
      } else if(input$pui_sample){ # Pui's dataset has some special # signs that need special read.table option
        bed_del1 <- readbed_svSize(input$bed1path_del,noChr = TRUE, commentChar="")
        bed_ins1 <- readbed_svSize(input$bed1path_ins,noChr = TRUE, commentChar="")
      } else if(!is.null(input$smap1path) & input$smap1path != ""){
        if (is.null(v1$smap1path) || input$smap1path != v1$smap1path) {
          v1$smap1path <- input$smap1path
          v1$smap1<-readsmap(v1$smap1path)
        }

        # Deletion
        smap_del1 <- get_sv_type_minlen(v1$smap1,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del1 <- select(smap_del1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins1 <- get_sv_type_minlen(v1$smap1,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins1 <- select(smap_ins1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

      } else {
        if(!is.null(input$bed1path_del) & input$bed1path_del != ""){
          bed_del1 <- readbed_svSize(input$bed1path_del,noChr = TRUE)
        }
        if(!is.null(input$bed1path_ins) & input$bed1path_ins != ""){
          bed_ins1 <- readbed_svSize(input$bed1path_ins,noChr = TRUE)
        }
      }

      # Add buffer to file 1 bed files
      bed_del1_20kb <- add_buffer(bed_del1,buffer=v$buffer)
      bed_ins1_20kb <- add_buffer(bed_ins1,buffer=v$buffer)


      # Read smap2/beds into bed dataframe
      if(!is.null(input$smap2)){
        if (is.null(v1$smap2path) || input$smap2$datapath != v1$smap2path){
          v1$smap2path <- input$smap2$datapath
          v1$smap2<-readsmap(v1$smap2path)
        }
        # Deletion
        smap_del2 <- get_sv_type_minlen(v1$smap2,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del2 <- select(smap_del2,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins2 <- get_sv_type_minlen(v1$smap2,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins2 <- select(smap_ins2,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
      }
      else if(!is.null(input$bed2_del)){
        bed_del2 <- readbed_svSize(input$bed2_del$datapath,noChr = TRUE)
        bed_ins2 <- readbed_svSize(input$bed2_ins$datapath,noChr = TRUE)
      }
      else if(!is.null(input$smap2path) & input$smap2path != "" ){
        if (is.null(v1$smap2path) || input$smap2path != v1$smap2path) {
          v1$smap2path <- input$smap2path
          v1$smap2<-readsmap(v1$smap2path)
        }

        # Deletion
        smap_del2 <- get_sv_type_minlen(v1$smap2,svType="deletion",minLen=v$minLen, minConf=v$minConf)
        bed_del2 <- select(smap_del2,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

        # Insertion
        smap_ins2 <- get_sv_type_minlen(v1$smap2,svType="insertion",minLen=v$minLen, minConf=v$minConf)
        bed_ins2 <- select(smap_ins2,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

      } else {
        # browser()
        if(!is.null(input$bed2path_del) & input$bed2path_del != "" ){
          bed_del2 <- readbed_svSize(input$bed2path_del,noChr = TRUE)
        }
        if(!is.null(input$bed2path_ins) & input$bed2path_ins != "" ){
          bed_ins2 <- readbed_svSize(input$bed2path_ins,noChr = TRUE)
        }
      }

      result_del1 <- intersect_bed(bed1=bed_del1_20kb,bed2=bed_del2,svratio_threshold=v$svratio_threshold) # SMAP1 based overlap deletion
      result_ins1 <- intersect_bed(bed1=bed_ins1_20kb,bed2=bed_ins2,svratio_threshold=v$svratio_threshold) # SMAP1 based overlap insertion
      result_del2 <- intersect_bed(bed2=bed_del1_20kb,bed1=bed_del2,svratio_threshold=v$svratio_threshold) # SMAP2 based overlap deletion
      result_ins2 <- intersect_bed(bed2=bed_ins1_20kb,bed1=bed_ins2,svratio_threshold=v$svratio_threshold) # SMAP2 based overlap insertion
      result <- c(result_del1,result_ins1,result_del2,result_ins2)
    })
    return(result)
  })

  # Checkbox to show/not-show unique SVs in a table
  observe({
    if(input$show_unique_bed){
      unique_bed_list <- list(beds()[[5]],beds()[[10]],beds()[[15]],beds()[[20]])
    } else{
      unique_bed_list <- vector("list", 4)
    }
    output$unique_bed <- renderTable({
      unique_bed_list[[1]]
    },
    caption="Unique SV in file 1",
    caption.placement = getOption("xtable.caption.placement", "top"))

    output$unique_bed2 <- renderTable({
      unique_bed_list[[2]]
    },
    caption="Unique SV in file 1",
    caption.placement = getOption("xtable.caption.placement", "top"))

    output$unique_bed3 <- renderTable({
      unique_bed_list[[3]]
    },
    caption="Unique SV in file 2",
    caption.placement = getOption("xtable.caption.placement", "top"))

    output$unique_bed4 <- renderTable({
      unique_bed_list[[4]]
    },
    caption="Unique SV in file 2",
    caption.placement = getOption("xtable.caption.placement", "top"))
  })

  # Download bed file for unique deletion SV, file-1 based
  output$download_unique_bed1 <- downloadHandler(
    filename = function() { paste('file1_uniq_deletion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[5]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for unique insertion SV, file-1 based
  output$download_unique_bed2 <- downloadHandler(
    filename = function() { paste('file1_uniq_insertion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[10]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for unique deletion SV, file-2 based
  output$download_unique_bed3 <- downloadHandler(
    filename = function() { paste('file2_uniq_deletion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[15]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for unique insertion SV, file-2 based
  output$download_unique_bed4 <- downloadHandler(
    filename = function() { paste('file2_uniq_insertion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[20]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for overlapped deletion SV, file-1 based
  output$download_overlap_bed1 <- downloadHandler(
    filename = function() { paste('file1_overlap_deletion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[4]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for overlapped insertion SV, file-1 based
  output$download_overlap_bed2 <- downloadHandler(
    filename = function() { paste('file1_overlap_insertion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[9]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for overlapped deletion SV, file-2 based
  output$download_overlap_bed3 <- downloadHandler(
    filename = function() { paste('file2_overlap_deletion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[14]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Download bed file for overlapped insertion SV, file-2 based
  output$download_overlap_bed4 <- downloadHandler(
    filename = function() { paste('file2_overlap_insertion', '.bed', sep='') },
    content = function(file) {
      write.table(beds()[[19]], file, quote=FALSE,col.names=FALSE, row.names = FALSE, sep = "\t")
    }
  )

  # Plot deletion barplot, file-1 based
  output$hist <- renderPlot({

    # browser()
    v$size_stratify_result_del <- barplot_sensitivity(bedintersect_qry=beds()[[1]],
                                                      bedintersect_ref=beds()[[2]],
                                                      size_bin=v$size_bin,
                                                      bin_names=v$bin_names,
                                                      ylab="Sensitivity (%)")

  })

  # Plot insertion barplot, file-1 based
  output$hist2 <- renderPlot({
    v$size_stratify_result_ins <- barplot_sensitivity(bedintersect_qry=beds()[[6]],
                                                      bedintersect_ref=beds()[[7]],
                                                      size_bin=v$size_bin,
                                                      bin_names=v$bin_names,
                                                      ylab="Sensitivity (%)")
  })

  # Plot deletion barplot, file-2 based
  output$hist3 <- renderPlot({
    v$size_stratify_result_del2 <- barplot_sensitivity(bedintersect_qry=beds()[[11]],
                                                       bedintersect_ref=beds()[[12]],
                                                       size_bin=v$size_bin,
                                                       bin_names=v$bin_names,
                                                       ylab="Sensitivity (%)")
  })

  # Plot insertion barplot, file-2 based
  output$hist4 <- renderPlot({
    v$size_stratify_result_ins2 <- barplot_sensitivity(bedintersect_qry=beds()[[16]],
                                                       bedintersect_ref=beds()[[17]],
                                                       size_bin=v$size_bin,
                                                       bin_names=v$bin_names,
                                                       ylab="Sensitivity (%)")
  })

  # Plot deletion scatter plot for SV size distribution, file-1 based
  output$svSize_distribution_del <- renderPlot({

    v2$xlim <- input$xlim
    v2$bed1name <- input$bed1name
    v2$bed2name <- input$bed2name
    scatterPlot_svSize(beds()[[3]],xlim=v2$xlim,ylim=v2$xlim,xlab=isolate(v2$bed1name),ylab=isolate(v2$bed2name))

  })

  # Plot insertion scatter plot for SV size distribution, file-1 based
  output$svSize_distribution_ins <- renderPlot({
    v2$xlim <- input$xlim
    v2$bed1name <- input$bed1name
    v2$bed2name <- input$bed2name
    scatterPlot_svSize(beds()[[8]],xlim=v2$xlim,ylim=v2$xlim,xlab=isolate(v2$bed1name),ylab=isolate(v2$bed2name))

  })

  # Print overlap table for deletion
  output$stats <- renderPrint({
    v$size_stratify_result_del
  })

  # Print overlap table for insertion
  output$stats2 <- renderPrint({
    v$size_stratify_result_ins
  })

  # Print overlap table for deletion
  output$stats3 <- renderPrint({
    v$size_stratify_result_del2
  })

  # Print overlap table for insertion
  output$stats4 <- renderPrint({
    v$size_stratify_result_ins2
  })

  # Help messages
  observe({
    if(input$show_help){
      help_version_msg <- paste0("You are using version ",version,". To load the latest version, you have to restart your web browser.")
      help_input_msg <- paste("Please choose only 1 input method. <br>
        Once a file is uploaded, you cannot unload. Please start a new run in another webpage. <br>
        If you choose to input BED files, you have to provide both deletion and insertion files. <br>
        Please remove \'track name\' row in BED file. <br>
        Anything after \'#\' is comment, therefore not imported. <br>", img(height=230,width=300,src="sensitivity_definition.PNG"))
      # help_input_img <- img(height=50,width=130,src="bionanogenomics_logo.JPG")))
      # help_bed_format_msg <- "BED file format:<br><span style=\"display:block; width: 40px;\">1 5246919  5246920  id_1_5246919_test  1323<br>2  5646945  5856913  id_1_5646945_test  7323</span>"
      help_bed_format_msg <- "BED file format:&emsp;(Chromosome&emsp;Start&emsp;End&emsp;ID&emsp;SV_Size) <br>
        1&emsp;5246919&emsp;5246920&emsp;id_1_5246919_test&emsp;1323<br>
        2&emsp;5646945&emsp;5856913&emsp;id_1_5646945_test&emsp;7323"
      help_stratify_msg <- "Minimum length threshold for SV size, Minimum raw confidence threshold only apply to SMAP file. <br>
        Buffer is added to file 1 coordinates, both sides of each SV."
      help_scatter_plot_msg <- "Here is showing the SVs (with buffer above) that are overlapped by >=1 bp, without SV size comparison. The SVs without an overlap are not shown."
    } else {
      help_version_msg <- ""
      help_input_msg <- ""
      help_bed_format_msg <- ""
      help_stratify_msg <- ""
      help_scatter_plot_msg <- ""
    }
    output$help_version <- renderText({
      msg_to_print <- sprintf('<font color="%s">%s</font>','blue',help_version_msg)
    })
    output$help_input <- renderText({
      msg_to_print <- sprintf('<font color="%s">%s</font>','blue',help_input_msg)
    })
    output$help_bed_format <- renderText({
      msg_to_print <- sprintf('<font color="%s">%s</font>','blue',help_bed_format_msg)
    })
    output$help_stratify <- renderText({
      msg_to_print <- sprintf('<font color="%s">%s</font>','blue',help_stratify_msg)
    })
    output$help_scatter_plot <- renderText({
      msg_to_print <- sprintf('<font color="%s">%s</font>','blue',help_scatter_plot_msg)
    })
  })

}

shinyApp(ui = ui,server=server)
