COMBO=/home/users/csecol/software/internal/ra4913_p4890_h4741
REFALIGNER=${COMBO}/tools/RefAligner
IDFILE=/home/users/tliang/r_script/svRTools/project_rPackage/svComp/inst/extdata/NA12878_chr22_q.id
QCMAP=/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap
OUT=/home/users/tliang/r_script/svRTools/project_rPackage/svComp/inst/extdata/NA12878_chr22_q

COMMAND="$REFALIGNER -selectidf $IDFILE -f -merge -i $QCMAP -o $OUT -stderr -stdout"

echo $COMMAND
$COMMAND

