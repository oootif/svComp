#' svComp_bedNGS_smap_sizeStratify
#'
#' This wrapper function allows you to plot sensitivity by SV size.
#' @param bedNGS_del A data frame of bed file from NGS, for deletion
#' @param bedNGS_ins A data frame of bed file from NGS, for insertion
#' @param smap A data frame of smap file from BNG
#' @param minLen Default 0
#' @param minConf Default 3
#' @param buffer Default 20000 (bp)
#' @param size_bin Default c(0, 2000, 5000, 100000000)
#' @param bin_names Default c("0-2","2-5","5+")
#' @return dataframe scattor plot of SV size concordance, a barplot of sensitivity by bin, a data frame of stats
#' @keywords sv
#' @export
#' @import dplyr
svComp_bedNGS_smap_sizeStratify <- function(bedNGS_del, bedNGS_ins, smap, minLen = 0, minConf = 3, buffer=20000,
                                   size_bin=c(0, 2000, 5000, 100000000), bin_names=c("0-2","2-5","5+")){

  # NGS
  # Add buffer to NGS bed files
  bedNGS_del_20kb <- add_buffer(bedNGS_del,buffer=buffer)
  bedNGS_ins_20kb <- add_buffer(bedNGS_ins,buffer=buffer)

  # BNG Deletion
  smap_del <- get_sv_type_minlen(smap,svType="deletion",minLen=minLen, minConf=minConf)
  bed_del <- select(smap_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

  # BNG Insertion
  smap_ins <- get_sv_type_minlen(smap,svType="insertion",minLen=minLen, minConf=minConf)
  bed_ins <- select(smap_ins,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

#   Overlap Enternal Bed and Internal Bed
#   bed1: External bed
#   bed2: Internal bed (BNG)
  result_del <- overlap_bed_svSizeRatio(bed1=bedNGS_del_20kb,bed2=bed_del)
  overlap_summary_del <- as.data.frame(result_del[1],row.names =c("ngsBased_deletion.all","bngBased_deletion.all"))
  bed1_overlapped_del <- as.data.frame(result_del[2])
  bed2_overlapped_del <- as.data.frame(result_del[3])
  bed1_unique_del <- as.data.frame(result_del[4])
  bed2_unique_del <- as.data.frame(result_del[5])

  result_ins <- overlap_bed_svSizeRatio(bed1=bedNGS_ins_20kb,bed2=bed_ins)
  overlap_summary_ins <- as.data.frame(result_ins[1],row.names =c("ngsBased_insertion.all","bngBased_insertion.all"))
  bed1_overlapped_ins <- as.data.frame(result_ins[2])
  bed2_overlapped_ins <- as.data.frame(result_ins[3])
  bed1_unique_ins <- as.data.frame(result_ins[4])
  bed2_unique_ins <- as.data.frame(result_ins[5])

  names <- c("chr","start","end","id","svSize","Type")
  bed_all <- rbind(mutate(bed1_overlapped_del,Type="NGS_overlap_del") %>% setNames(names),
        mutate(bed2_overlapped_del,Type="BNG_overlap_del") %>% setNames(names),
        mutate(bed1_unique_del,Type="NGS_unique_del") %>% setNames(names),
        mutate(bed2_unique_del,Type="BNG_unique_del") %>% setNames(names),
        mutate(bed1_overlapped_ins,Type="NGS_overlap_ins") %>% setNames(names),
        mutate(bed2_overlapped_ins,Type="BNG_overlap_ins") %>% setNames(names),
        mutate(bed1_unique_ins,Type="NGS_unique_ins") %>% setNames(names),
        mutate(bed2_unique_ins,Type="BNG_unique_ins") %>% setNames(names)
        )

## Sensitivity stratify by SV size

  size_bin <- size_bin
  bin_names <- bin_names
  print("NGS based Deletion")
  ngs_stratify_del <- analyze_sensitivity(bed1=bedNGS_del_20kb,bed2=bed_del,size_bin=size_bin,bin_names=bin_names,bed1name="NGS_Deletion_20kb",bed2name="BNG_Deletion")
  print("NGS based Insertion")
  ngs_stratify_ins <- analyze_sensitivity(bed1=bedNGS_ins_20kb,bed2=bed_ins,size_bin=size_bin,bin_names=bin_names,bed1name="NGS_Insertion_20kb",bed2name="BNG_Insertion")

  print("BNG based Deletion")
  bng_stratify_del <- analyze_sensitivity(bed2=bedNGS_del_20kb,bed1=bed_del,size_bin=size_bin,bin_names=bin_names,bed2name="NGS_Deletion_20kb",bed1name="BNG_Deletion")
  print("BNG based Insertion")
  bng_stratify_ins <- analyze_sensitivity(bed2=bedNGS_ins_20kb,bed1=bed_ins,size_bin=size_bin,bin_names=bin_names,bed2name="NGS_Insertion_20kb",bed1name="BNG_Insertion")

  # Columns in stratify_result:
  # bedNGS-stratified-deletion (multiple rows)
  # bedNGS-stratified-insertion (multiple rows)
  # smapBNG-stratified-deletion (multiple rows)
  # smapBNG-stratified-insertion (multiple rows)
  # bedNGS-Total-deletion
  # smapBNG-Total-deletion
  # bedNGS-Total-insertion
  # smapBNG-Total-insertion
  stratify_result <- rbind("ngsBased_deletion"=ngs_stratify_del,
                           "ngsBased_insertion"=ngs_stratify_ins,
                           "bngBased_deletion"=bng_stratify_del,
                           "bngBased_insertion"=bng_stratify_ins,
                          setNames(dplyr::select(overlap_summary_del,overlap_num,all_SV_num,overlap_percent),colnames(ngs_stratify_del)),
                          setNames(dplyr::select(overlap_summary_ins,overlap_num,all_SV_num,overlap_percent),colnames(ngs_stratify_ins))
                          )
  bed_list = list(stratify_result, bed_all)


  return(bed_list)
}

#' @export
svComp_smap_sizeStratify <- function(smap1, smap2,
                                     minLen = 0,
                                     minConf = 3,
                                     buffer = 20000,
                                     size_bin = c(0, 2000, 5000, 100000000),
                                     bin_names = c("0-2", "2-5", "5+")) {

  # Deletion
  smap_del1 <- get_sv_type_minlen(smap1,svType="deletion",minLen=minLen, minConf=minConf)
  bed_del1 <- select(smap_del1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize) # Convert smap to bed

  # Insertion
  smap_ins1 <- get_sv_type_minlen(smap1,svType="insertion",minLen=minLen, minConf=minConf)
  bed_ins1 <- select(smap_ins1,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

  bed_list <- svComp_bedNGS_smap_sizeStratify(bedNGS_del = bed_del1,
                                              bedNGS_ins = bed_ins1,
                                              smap = smap2,
                                              size_bin = size_bin,
                                              bin_names = bin_names
  )
  return(bed_list)
}

# To parse the output statistic from svComp_smap_sizeStratify() and svComp_bedNGS_smap_sizeStratify()
#' @export
get_venn_diagram_element <- function(df){
  df2 <- df %>% mutate(unique=total-overlapped,uniquePerc=percent(unique/total))
  rownames(df2)<-rownames(df)
  return(df2)
}
