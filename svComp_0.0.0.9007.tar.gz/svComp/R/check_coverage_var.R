#' @export
check_coverage_var_filename <- function(f_rcmap,win_size=1000000,win_shift=300000,ylim=NULL,main_prefix="chr", makepdf=FALSE, f_pdf_prefix=NULL){
  rcmap <- readcmap1(f_rcmap)
  result <- check_coverage_var(rcmap=rcmap,
                     win_size=win_size,
                     win_shift=win_shift,
                     ylim=ylim,
                     main_prefix=main_prefix,
                     makepdf=makepdf,
                     f_pdf=paste0(f_pdf_prefix,".pdf")
                     )

  # Save result as rds file, for easy track and comparison
  rdata <- paste0(f_pdf_prefix,".rds")
  saveRDS(result,rdata)
  return(result)
}

# check_coverage_var(rcmap=rcmap_mol2ref22, win_shift=1000000,win_size=5000000)
# check_coverage_var(rcmap=rcmap_mol2refmerge, win_size=5000000)
#' @export
check_coverage_var <- function(rcmap,win_size=1000000,win_shift=300000,ylim=NULL,main_prefix="chr", makepdf=FALSE, f_pdf=NULL){
  chr <- as.numeric(unique(rcmap$CMapId))
  win_means_chr <- NULL
  win_var_chr <- NULL
  chr_means_coverage <- NULL
  if(makepdf){
    pdf(f_pdf)
    par(mfrow = c(3,1))
  }

  try({
    #   for(ch in chr){
    for(ch in seq(1,24,1)){
      print(ch)
      win_means <- NULL
      rcmap1 <- rcmap %>% filter(CMapId == ch)
      win_bin <- seq(min(rcmap1$Position),max(rcmap1$Position),by=win_shift)
      for(i in 1:length(win_bin)){
        #   i=1
        win_mean <- rcmap %>% filter(CMapId==ch, Position > win_bin[i] , Position < win_bin[i]+win_size) %>% summarize(mean(Coverage))
        win_means<- c(win_means,win_mean)
        #   coverage_plot(f_rcmap_mol2ref22,xlim=c(win_bin[i],win_bin[i+1]))
      }
      plot(unlist(win_means), main=paste(main_prefix,ch),pch=20,type="o",ylim=ylim)
      win_means_num <- as.numeric(as.character(unlist(win_means)))
      win_var_chr[[ch]] <- ifelse(length(win_means_num) >0, var(win_means_num,na.rm=TRUE), 0)
      win_means_chr[[ch]]<-unlist(win_means)
      chr_means_coverage[[ch]] <- rcmap1 %>% summarize(mean(Coverage))
    }
  })

  if(makepdf){
    dev.off()
  }
  all_win_var <- var(as.numeric(as.character(unlist(win_means_chr))),na.rm=TRUE)
  mean_coverage <- rcmap %>% summarize(mean(Coverage))
  mean_occurance <- rcmap %>% summarize(mean(Occurrence))
  result <- list(all_win_var, mean_coverage, mean_occurance, win_var_chr, chr_means_coverage, win_means_chr)

  return(result)
}



