#' Analyze sensitivity by SV size
#'
#' This function allows you to plot sensitivity by SV size.
#'
#' @param bed1 bed1 will be the numerator for bedTools intersect overlap. Require SV size with column name svSize
#' @param bed2 bed2 will be the denominator for bedTools intersect overlap.
#' @param optString Extra options for bedTools intersect. Default: "-wao" Other example: "-f 0.50 -r" for 50 percent recipical overlap.
#' @param size_bin a numeric vector for size bin range. Example: c(0, 500, 1000)
#' @param bin_names a character vector for bin size names. Will be one less element than size_bin. Example: c("0-0.5","0.5-1")
#' @param xlim xlim for SV size scattor plot. Default: c(0,150000). Can set NULL.
#' @param ylim ylim for SV size scattor plot. Default: c(0,150000). Can set NULL.
#' @param svratio_threshold SV ratio threshold, min(SV1,SV2)/max(SV1,SV2). Default: 0.5
#' @return size_stratify_result a scattor plot of SV size concordance, a barplot of sensitivity by bin
#' @export
# size_bin <- c(0, 500, 1000, 2000, 5000, 10000,15000,20000,30000,50000,70000,100000,150000,200000,300000,500000,1500000)
# bin_names <- c("0-0.5","0.5-1","1-2","2-5","5-10","10-15","15-20","20-30","30-50","50-70","70-100","100-150","150-200","200-300","300-500","500+")
# analyze_sensitivity(bed1=NA12878_del_pui_20kb, bed2=NA12878_del_all_con3, size_bin=size_bin, bin_names=bin_names)
analyze_sensitivity <- function(bed1, bed2, optString="-wao", size_bin, bin_names, xlim=c(0,150000), ylim=c(0,150000), svratio_threshold=0.5,bed1name=NULL,bed2name=NULL){
  bt_result1a <- bedTools(functionstring="intersect",bed1=bed1,bed2=bed2,optString=optString)
  bt_result2a <- as.data.frame(add_names_bedintersect(bt_result1a))
  overlap_bed1 <- dplyr::filter(bt_result2a,matches!=0) # Get all the overlapped SVs (>=1bp) in Pui
  bed1_overlap <- overlap_bed1 %>% # make SV size value positive
    dplyr::mutate(a_score=abs(a_score),b_score=abs(b_score))

  bed1_overlap_wSize_unique <- filter_sizeZero_svRatio_BNG_bedintersect(bed1_overlap,svratio_threshold=svratio_threshold)

  # Sensitivity barplot for overlap/all
  size_stratify_result <- barplot_sensitivity(bedintersect_qry=bed1_overlap_wSize_unique$a_score,bedintersect_ref=bed1$svSize, size_bin=size_bin, bin_names=bin_names,ylab="Sensitivity (%)")

  # Make scatter plot for SV size compare for overlapped SVs
  scatterPlot_svSize(bed1_overlap,xlim=xlim,ylim=ylim,xlab=bed1name,ylab=bed2name)
  return(size_stratify_result)
}
