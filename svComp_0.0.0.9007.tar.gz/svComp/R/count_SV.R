#' Count SV numbers for all SV types in smap
#'
#' This function allows you to Count SV based on all the SV types in the given smap data frame
#' @param smap a dataframe. Require column: "SmapEntryID", "Type", "Confidence". For SV2.0, require extra column "GenotypeGroup". Example: a smap data frame
#' @param conf a minimum confidence score. Default: 3
#' @param svVersion an integer for SV version (SV1.0 or SV2.0).  Default: 2
#' @return matrix
#' @keywords smap sv
#' @export
#' @examples
#' #count_SV(smap_dad)
#' #count_SV(smap_dad,conf=7)
#' #Required columns:
#'  #   SmapEntryID     Type Confidence GenotypeGroup
#'  #1         157 deletion     157.66            -1
#'  #5         352 deletion     603.49           138
#'
count_SV <- function(smap, conf=3, svVersion=2){
  if (ncol(smap)<20){
    print("Note: You are using smap file from SV1.0, which does not have GenotypeGroup column. No overlapped SV is grouped. ")
    svVersion = 1
  }

  svTypes <- (dplyr::select(smap,Type) %>% unique %>% dplyr::arrange(Type))[,1]
  count2print <- c()
  for (s in svTypes){
    confidence = ifelse(grepl("insertion",s)||grepl("deletion",s), conf, -2)
    counts <- count_SV_svType(smap, conf=confidence, svType=s,svVersion=svVersion)
    count2print <- rbind(count2print,c(s,counts))
  }
  return(count2print)
}

count_SV_svType <- function(smap, conf=-2, svType, svVersion=2){
  count_total<-0
  if (svVersion ==1){
    count_total <- smap %>% dplyr::filter(Type==svType & Confidence > conf) %>% unique %>% nrow
  } else {
    count1 <- smap %>% dplyr::filter(GenotypeGroup != -1 & Type==svType & Confidence > conf) %>%
      dplyr::select(GenotypeGroup) %>% unique %>% nrow
    count2 <- smap %>% dplyr::filter(GenotypeGroup == -1 & Type==svType & Confidence > conf) %>%
      dplyr::select(SmapEntryID) %>% unique %>% nrow
    count_total <- count1 + count2
  }
  return(count_total)
}


