#' Get Trio overlapping stats table
#' @param f_smap_ofs f_smap_dad f_smap_mom f_xmap_dad f_xmap_mom f_qcmap_dad f_qcmap_mom minLen minConf
#' @return dataframe of stats for all the smap entries
#' @keywords indel labels xmap smap
#' @export
# @examples
# trio_hap_refsplit <- trio_indel(
# f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
# f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
# f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
# f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
# f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged.xmap",
# f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
# f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_refsplit3/merged_smaps/exp_refineFinal1_merged_q.cmap",
# minLen=0,
# minConf=3
# )
trio_indel <- function(f_smap_ofs, f_smap_dad,f_smap_mom,f_xmap_dad,f_xmap_mom,f_qcmap_dad,f_qcmap_mom,minLen=0,minConf=3) {
  Type="deletion"
  del_denovo <- trio_countLabelsCoverSV_svType(f_smap_ofs, f_smap_dad,f_smap_mom,f_xmap_dad,f_xmap_mom,f_qcmap_dad,f_qcmap_mom,svType=Type,minLen,minConf)
  if (!is.null(del_denovo)){
    del_denovo <- mutate(del_denovo, denovo=1,Type=Type)
  }
  del_nondenovo <- trio_countLabelsCoverSV_svType_nondenovo(f_smap_ofs, f_smap_dad,f_smap_mom,f_xmap_dad,f_xmap_mom,f_qcmap_dad,f_qcmap_mom,svType=Type,minLen,minConf)
  if (!is.null(del_nondenovo)){
    del_nondenovo <- mutate(del_nondenovo, denovo=0,Type=Type)
  }
  del_all <- rbind(del_denovo,del_nondenovo)

  Type="insertion"
  ins_denovo <- trio_countLabelsCoverSV_svType(f_smap_ofs, f_smap_dad,f_smap_mom,f_xmap_dad,f_xmap_mom,f_qcmap_dad,f_qcmap_mom,svType=Type,minLen,minConf)
  if (!is.null(ins_denovo)){
    ins_denovo <- mutate(ins_denovo, denovo=1,Type=Type)
  }
  ins_nondenovo <- trio_countLabelsCoverSV_svType_nondenovo(f_smap_ofs, f_smap_dad,f_smap_mom,f_xmap_dad,f_xmap_mom,f_qcmap_dad,f_qcmap_mom,svType=Type,minLen,minConf)
  if (!is.null(ins_nondenovo)){
    ins_nondenovo <- mutate(ins_nondenovo, denovo=0,Type=Type)
  }
  ins_all <- rbind(ins_denovo,ins_nondenovo)

  indel_all <- rbind(del_all, ins_all)
  indel_all <- arrange(indel_all,SmapEntryID)
  return(indel_all)
}
