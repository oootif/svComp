# Check if a linux software is installed in R PATH.
#'@export
#check_binary()
check_binary <-function (x = "bedtools", verbose = TRUE)
{
  default.path <- ""
  git.url <- ""
  return.flag <- FALSE
  if ("bedtools" == x) {
    git.url <- "https://github.com/arq5x/bedtools2"
    #path <- paste0(Sys.getenv("PATH"),":","/home/users/csecol/software/external/
    #Sys.setenv("PATH","")
  }

  cat(paste0("  * Checking path for ", x, "... "))
  if ("" == Sys.which(x)) {
    cat(paste0("FAIL\n"))
    path <- Sys.getenv("PATH")
    if ("" == git.url) {
      cat(paste0("    It can be downloaded from here: ",git.url, "\n"))
    }
  }
  else {
    cat(paste0("PASS\n    ", Sys.which(x), "\n"))
    return.flag <- TRUE
  }
  return(return.flag)
}
# <environment: namespace:svComp>
