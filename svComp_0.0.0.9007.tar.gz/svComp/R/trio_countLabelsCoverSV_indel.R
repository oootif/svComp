#' Count labels on GM for Trio
#'
#' This function allows you to get number of label sites in the cmap
#' @param string int filename svType minLen minConf
#' @return dataframe of a merged table of smap and xmap with number of labels
#' @keywords labels xmap smap
#' @export
# @examples
#trio_countLabelsCoverSV_svType(
#   f_smap_ofs="/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
#   f_smap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
#   f_smap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_filter_inversions.smap",
#   f_xmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
#   f_xmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged.xmap",
#   f_qcmap_dad="/mnt/bionf_tmp/tliang/data/20160407_NA12891_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
#   f_qcmap_mom="/mnt/bionf_tmp/tliang/data/20160407_NA12892_ulhg38hap/output/contigs/exp_refineFinal1_sv/merged_smaps/exp_refineFinal1_merged_q.cmap",
#   svType="deletion",
#   minLen=0,
#   minConf=3
# )

trio_countLabelsCoverSV_indel <- function(f_smap_ofs, f_smap_dad, f_smap_mom, f_xmap_dad, f_xmap_mom, f_qcmap_dad, f_qcmap_mom, svType,minLen=0, minConf=0){
  #### Happy Path ####
  # 1. Read smap
  smap_girl<- readsmap(f_smap_ofs)
  smap_dad<- readsmap(f_smap_dad)
  smap_mom<- readsmap(f_smap_mom)

  # 1b. Read xmap
  xmap_dad<- readxmap(f_xmap_dad)
  xmap_mom<- readxmap(f_xmap_mom)

  # 1c. Read _q.cmap; _r.cmap
  qcmap_dad<- readcmap1(f_qcmap_dad)
  qcmap_mom<- readcmap1(f_qcmap_mom)

#   print("after read file")

  # 2. Filter and selected usable region, seperate by deletion and insertion
  svType = "deletion"
  smap_girl_del <- get_sv_type_minlen(smap_girl,svType,minLen=minLen, minConf=minConf)
  smap_dad_del <- get_sv_type_minlen(smap_dad,svType,minLen=minLen, minConf=minConf)
  smap_mom_del <- get_sv_type_minlen(smap_mom,svType,minLen=minLen, minConf=minConf)

  svType = "insertion"
  smap_girl_ins <- get_sv_type_minlen(smap_girl,svType,minLen=minLen, minConf=minConf)
  smap_dad_ins <- get_sv_type_minlen(smap_dad,svType,minLen=minLen, minConf=minConf)
  smap_mom_ins <- get_sv_type_minlen(smap_mom,svType,minLen=minLen, minConf=minConf)

  # 3. Convert smap to bed
  bed_girl_del <- select(smap_girl_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
  bed_dad_del <- select(smap_dad_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
  bed_mom_del <- select(smap_mom_del,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

  bed_girl_ins <- select(smap_girl_ins,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
  bed_dad_ins <- select(smap_dad_ins,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)
  bed_mom_ins <- select(smap_mom_ins,RefcontigID1,RefStartPos,RefEndPos,SmapEntryID,svSize)

  # 4. bedtool overlap SV from parents and child
  bt_result_DM_del <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_mom_del,optString="-wao")
  bt_result_DF_del <- bedTools(functionstring="intersect",bed1=bed_girl_del,bed2=bed_dad_del,optString="-wao")
  bt_result_DM_del <- as.data.frame(add_names_bedintersect(bt_result_DM_del))
  bt_result_DF_del <- as.data.frame(add_names_bedintersect(bt_result_DF_del))

  bt_result_DM_ins <- bedTools(functionstring="intersect",bed1=bed_girl_ins,bed2=bed_mom_ins,optString="-wao")
  bt_result_DF_ins <- bedTools(functionstring="intersect",bed1=bed_girl_ins,bed2=bed_dad_ins,optString="-wao")
  bt_result_DM_ins <- as.data.frame(add_names_bedintersect(bt_result_DM_ins))
  bt_result_DF_ins <- as.data.frame(add_names_bedintersect(bt_result_DF_ins))

  # 5. Get de novo offspring SV
  smap_girl_del_denovo <- get_offspring_denovo_sv(bedintersect_father=bt_result_DF_del, bedintersect_mother=bt_result_DM_del,ref_smap=smap_girl_del)
  smap_girl_ins_denovo <- get_offspring_denovo_sv(bedintersect_father=bt_result_DF_ins, bedintersect_mother=bt_result_DM_ins,ref_smap=smap_girl_ins)
#   smap_girl_del_denovo_not <- filter(smap_girl_del,!SmapEntryID%in%(smap_girl_del_denovo$SmapEntryID))

  # 6. Add number of sites for query in xmap data frame
  if (ncol(smap_girl) <= 20){
    labels_dad_del <- countLabelsOnGM_coverSV_sv1.0(smap=smap_girl_del_denovo,xmap_p2=xmap_dad,qcmap_p2=qcmap_dad)
    labels_mom_del <- countLabelsOnGM_coverSV_sv1.0(smap=smap_girl_del_denovo,xmap_p2=xmap_mom,qcmap_p2=qcmap_mom)
    labels_dad_ins <- countLabelsOnGM_coverSV_sv1.0(smap=smap_girl_ins_denovo,xmap_p2=xmap_dad,qcmap_p2=qcmap_dad)
    labels_mom_ins <- countLabelsOnGM_coverSV_sv1.0(smap=smap_girl_ins_denovo,xmap_p2=xmap_mom,qcmap_p2=qcmap_mom)
    labels_dad <- rbind(labels_dad_del,labels_dad_ins)
    labels_mom <- rbind(labels_mom_del,labels_mom_ins)
  } else{
    labels_dad_del <- countLabelsOnGM_coverSV(smap=smap_girl_del_denovo,xmap_p2=xmap_dad,qcmap_p2=qcmap_dad)
    labels_mom_del <- countLabelsOnGM_coverSV(smap=smap_girl_del_denovo,xmap_p2=xmap_mom,qcmap_p2=qcmap_mom)
    labels_dad_ins <- countLabelsOnGM_coverSV(smap=smap_girl_ins_denovo,xmap_p2=xmap_dad,qcmap_p2=qcmap_dad)
    labels_mom_ins <- countLabelsOnGM_coverSV(smap=smap_girl_ins_denovo,xmap_p2=xmap_mom,qcmap_p2=qcmap_mom)
    labels_dad <- rbind(labels_dad_del,labels_dad_ins)
    labels_mom <- rbind(labels_mom_del,labels_mom_ins)
  }
  lab_dad <- labels_dad %>% mutate(sample="Father")
  lab_mom <- labels_mom %>% mutate(sample="Mother")
  labels_trio <- full_join(lab_dad,lab_mom) %>% arrange(SmapEntryID)

  return(labels_trio)
}

