# A Function to get number of sites in a CMAP
#' @export
get_numSites_df <- function(incmap) {
  cmap_numSites <- incmap %>% select(CMapId,NumSites) %>% unique
  return(cmap_numSites)
}

# Input a rcmap, a CMapID, a coordinate, eg. Start position of a SV
# Returns RefStartIdx, a label ID on the rcmap
#' @export
get_RefStartIdx_from_coord <- function(refcmap, cmap_id, position){
  position_list <- refcmap %>% filter(CMapId==cmap_id, Position <=position)
  RefStartIdx <- position_list[nrow(position_list),]$SiteID
  return(RefStartIdx)
}

# Input a rcmap, a CMapID, a coordinate, eg. End position of a SV
# Returns RefEndIdx, a label ID on the rcmap
#' @export
get_RefEndIdx_from_coord <- function(refcmap, cmap_id, position){
  position_list <- refcmap %>% filter(CMapId==cmap_id, Position >=position)
  RefEndIdx <- position_list[1,]$SiteID
  return(RefEndIdx)
}