#' A Function to read smap into a dataframe
#'
#' @param smap filename
#' @return dataframe for a smap
#' @keywords smap
#' @export
#' @examples
#' #readsmap(filename)
#' ##TODO: optimize readsmap, so it's not too column number dependent

readsmap <- function( filename ) {
  smap <- NULL;
  try ( {

    #message(filename)
    smap <- read.table(filename, comment.char="#", header=FALSE, stringsAsFactors=FALSE, nrows=1000000)

    if (ncol(smap) == 12) {
      colnames( smap ) <- c( "SmapEntryID", "QryContigID", "RefcontigID1", "RefcontigID2",
                             "QryStartPos", "QryEndPos", "RefStartPos", "RefEndPos",
                             "Confidence", #check for column for orientation
                             "Type", "XmapID1", "XmapID2"
      )
    } else if (ncol(smap) == 13) {
      #01222015 EL
      colnames( smap ) <- c( "SmapEntryID", "QryContigID", "RefcontigID1", "RefcontigID2",
                             "QryStartPos", "QryEndPos", "RefStartPos", "RefEndPos",
                             "Confidence",
                             "Type", "XmapID1", "XmapID2","LinkID"
      )

      #             colnames( smap ) <- c( "SmapEntryID", "QryContigID", "RefcontigID1", "RefcontigID2",
      #                                    "QryStartPos", "QryEndPos", "RefStartPos", "RefEndPos",
      #                                    "Orientation", "Confidence", #check for column for orientation
      #                                    "Type", "XmapID1", "XmapID2"
      #             )
    } else if (ncol(smap)==17) {
      #03242015 EL
      colnames(smap) <- c("SmapEntryID","QryContigID","RefcontigID1","RefcontigID2",
                          "QryStartPos","QryEndPos","RefStartPos","RefEndPos",
                          "Confidence","Type","XmapID1","XmapID2",
                          "LinkID","QryStartIdx","QryEndIdx","RefStartIdx","RefEndIdx")
    } else if (ncol(smap)==18) {
      colnames(smap) <- c("SmapEntryID","QryContigID","RefcontigID1","RefcontigID2",
                          "QryStartPos","QryEndPos","RefStartPos","RefEndPos",
                          "Confidence","Type","XmapID1","XmapID2",
                          "LinkID","QryStartIdx","QryEndIdx","RefStartIdx","RefEndIdx",
                          "Zygosity")
    } else if (ncol(smap)==20) {
      colnames(smap) <- c("SmapEntryID","QryContigID","RefcontigID1","RefcontigID2",
                          "QryStartPos","QryEndPos","RefStartPos","RefEndPos",
                          "Confidence","Type","XmapID1","XmapID2",
                          "LinkID","QryStartIdx","QryEndIdx","RefStartIdx","RefEndIdx",
                          "Zygosity","Genotype","GenotypeGroup")
    } else if (ncol(smap)==21) {
      colnames(smap) <- c("SmapEntryID","QryContigID","RefcontigID1","RefcontigID2",
                          "QryStartPos","QryEndPos","RefStartPos","RefEndPos",
                          "Confidence_1","Type","XmapID1","XmapID2",
                          "LinkID","QryStartIdx","QryEndIdx","RefStartIdx","RefEndIdx",
                          "Zygosity","Genotype","GenotypeGroup","Confidence")
    }
  },
  silent = TRUE #added 03202014 to suppres read smap error there are no lines
  ) #try
  return(smap)
} #readSMap
