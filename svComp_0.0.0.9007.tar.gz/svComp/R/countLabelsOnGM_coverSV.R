#' Count labels on GM with coverage around the SV on offspring
#'
#' This function allows you to get number of label sites in the cmap
#' @param smap xmap qcmap
#' @return dataframe of a merged table of smap and xmap with number of labels
#' @keywords labels xmap smap
#' @export
#' @examples
#' #countLabelsOnGM_coverSV(smap_daughter,xmap_father, qcmap_father)
# add_start_end_RefPos_to_xmap <- function(xmap_p2){
#   xmap_3 <- xmap_p2 %>% dplyr::group_by(QryContigID) %>% dplyr::summarise(minRefStartPos=min(RefStartPos), maxRefEndPos=max(RefEndPos))
#   xmap_numSites <- dplyr::left_join(xmap_p2, xmap_3)
#   return(new_xmap)
# }
countLabelsOnGM_coverSV <- function(smap,xmap_p2,qcmap_p2){
  xmap1 <-add_numSites_to_xmap(xmap_p2,qcmap_p2)

#   xmap1 <- add_start_end_RefPos_to_xmap(xmap0)

  sv_gm_coverage=data.frame()
  for (entry in 1:nrow(smap)) {
#      entry=13
#     print(entry)

    # Set offspring SV line coordinates
    offspring_chr <- smap[entry,"RefcontigID1"]
    offsprint_x1 <- smap[entry,"RefStartPos"]
    offsprint_x2 <- smap[entry,"RefEndPos"]
    offsprint_y1 = offsprint_y2 = 0

    start_ref_sv <- smap[entry,"RefStartIdx"] # Label ID on reference at start of SV
    end_ref_sv <- smap[entry,"RefEndIdx"] # Label ID on reference at the end of SV

    # Set parents GM coordinates
    xmap1_gm <- dplyr::filter(xmap1,RefcontigID==offspring_chr & RefStartPos<=offsprint_x2 & RefEndPos>=offsprint_x1) # Get xmap that covers the SV > 1bp

    if(nrow(xmap1_gm)>0){
      #Get number of labels from SV to end of genome map
      alignment_list <- rbind(lapply(xmap1_gm$Alignment,split_alignment))

      xmap1_gm$startLabel <- unlist(lapply(alignment_list,function(df) 
        ifelse(
          nrow(
              dplyr::filter(df,ref<=start_ref_sv) %>% dplyr::select(qry) %>% tail(1)
            ) == 0,
            NA,
            dplyr::filter(df,ref<=start_ref_sv) %>% dplyr::select(qry) %>% tail(1)
          )
        ))

      xmap1_gm$endLabel <- unlist(lapply(alignment_list,function(df) dplyr::filter(df,ref>=end_ref_sv)[1,] %>% dplyr::select(qry)))

      xmap1_gm$n_alignedLabel_bf_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref<=start_ref_sv)%>%select(qry))))) # Number of aligned labels on GM before the start of SV
      xmap1_gm$n_alignedLabel_af_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref>=end_ref_sv)%>%select(qry))))) # Number of aligned labels on GM after the end of SV

      # Set number of labels on GM before the start of SV, and after the end of SV
      xmap1_gm <- xmap1_gm %>%
        dplyr::mutate(startLabel1=ifelse(is.na(startLabel),0, startLabel), endLabel1=ifelse(is.na(endLabel),NumSites+1, endLabel)) %>% 
        dplyr::mutate(n_allLabel_bf_sv=pmin(startLabel1,endLabel1),n_allLabel_af_sv=NumSites-pmax(startLabel1,endLabel1)+1)

      # Select wanted columns from xmap and smap
      xmap_t1 <- xmap1_gm %>% 
        dplyr::select(1,QryContigID,RefcontigID,RefStartPos, RefEndPos, Confidence,n_alignedLabel_bf_sv,n_alignedLabel_af_sv,n_allLabel_bf_sv,n_allLabel_af_sv,startLabel,endLabel,NumSites)
      smap_t1 <- smap[entry,] %>% 
        dplyr::mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence,svSize.smap=svSize)%>% 
        dplyr::select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap,svSize.smap,Zygosity,GenotypeGroup)

      #   sv_gm_coverage <- full_join(smap_t1,xmap_t1)
      sv_gm_coverage <- plyr::rbind.fill(sv_gm_coverage,dplyr::full_join(smap_t1,xmap_t1,by="RefcontigID"))
    } else {
      # No genome map is found covering the SV region
      smap_t1 <- smap[entry,] %>% 
        dplyr::mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence,svSize.smap=svSize) %>% 
        dplyr::select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap,svSize.smap,Zygosity,GenotypeGroup)
      sv_gm_coverage <- plyr::rbind.fill(sv_gm_coverage,smap_t1)
    }
  }
  return(sv_gm_coverage)
}

countLabelsOnGM_coverSV_sv1.0 <- function(smap,xmap_p2,qcmap_p2){
  xmap1 <-add_numSites_to_xmap(xmap_p2,qcmap_p2)

  #   xmap1 <- add_start_end_RefPos_to_xmap(xmap0)

  sv_gm_coverage=data.frame()
  for (entry in 1:nrow(smap)) {
    #      entry=231

    # Set offspring SV line coordinates
    offspring_chr <- smap[entry,"RefcontigID1"]
    offsprint_x1 <- smap[entry,"RefStartPos"]
    offsprint_x2 <- smap[entry,"RefEndPos"]
    offsprint_y1 = offsprint_y2 = 0

    start_ref_sv <- smap[entry,"RefStartIdx"] # Label ID on reference at start of SV
    end_ref_sv <- smap[entry,"RefEndIdx"] # Label ID on reference at the end of SV

    # Set parents GM coordinates
    xmap1_gm <- dplyr::filter(xmap1,RefcontigID==offspring_chr & RefStartPos<=offsprint_x2 & RefEndPos>=offsprint_x1) # Get xmap that covers the SV > 1bp

    if(nrow(xmap1_gm)>0){
      #Get number of labels from SV to end of genome map
      alignment_list <- rbind(lapply(xmap1_gm$Alignment,split_alignment))

      
      xmap1_gm$startLabel <- unlist(lapply(alignment_list,function(df) 
        ifelse(
          nrow(
            dplyr::filter(df,ref<=start_ref_sv) %>% dplyr::select(qry) %>% tail(1)
          ) == 0,
          NA,
          dplyr::filter(df,ref<=start_ref_sv) %>% dplyr::select(qry) %>% tail(1)
        )
      ))
      
      xmap1_gm$endLabel <- unlist(lapply(alignment_list,function(df) dplyr::filter(df,ref>=end_ref_sv)[1,] %>% dplyr::select(qry)))
      
      xmap1_gm$n_alignedLabel_bf_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref<=start_ref_sv)%>%select(qry))))) # Number of aligned labels on GM before the start of SV
      xmap1_gm$n_alignedLabel_af_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref>=end_ref_sv)%>%select(qry))))) # Number of aligned labels on GM after the end of SV
      
      # Set number of labels on GM before the start of SV, and after the end of SV
      xmap1_gm <- xmap1_gm %>%
        dplyr::mutate(startLabel1=ifelse(is.na(startLabel),0, startLabel), endLabel1=ifelse(is.na(endLabel),NumSites+1, endLabel)) %>% 
        dplyr::mutate(n_allLabel_bf_sv=pmin(startLabel1,endLabel1),n_allLabel_af_sv=NumSites-pmax(startLabel1,endLabel1)+1)
      
      
      #       xmap1_gm$startLabel <- unlist(lapply(alignment_list,function(df) last(dplyr::filter(df,ref<=start_ref_sv)%>%dplyr::select(qry))))
#       xmap1_gm$startLabel <- unlist(lapply(alignment_list,function(df) ifelse(is.null(last(dplyr::filter(df,ref<=start_ref_sv)%>%dplyr::select(qry))),NA,last(dplyr::filter(df,ref<=start_ref_sv)%>%dplyr::select(qry)))))
#       xmap1_gm$endLabel <- unlist(lapply(alignment_list,function(df) (dplyr::filter(df,ref>=end_ref_sv)[1,]%>%dplyr::select(qry))))
#       #       xmap1_gm$endLabel <- unlist(lapply(alignment_list,function(df) ifelse(is.null((dplyr::filter(df,ref>=end_ref_sv))[1,]%>%dplyr::select(qry))),NA,(dplyr::filter(df,ref>=end_ref_sv))[1,]%>%dplyr::select(qry)))
# 
#       xmap1_gm$n_alignedLabel_bf_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref<=start_ref_sv)%>%select(qry))))) # Number of aligned labels on GM before the start of SV
#       xmap1_gm$n_alignedLabel_af_sv <- unlist(lapply(alignment_list,function(df) nrow(unique(dplyr::filter(df,ref>=end_ref_sv)%>%select(qry))))) # Number of aligned labels on GM after the end of SV
# 
#       # Set number of labels on GM before the start of SV, and after the end of SV
#       xmap1_gm <- xmap1_gm %>% dplyr::mutate(n_allLabel_bf_sv=pmin(startLabel,endLabel)-1,n_allLabel_af_sv=NumSites-pmax(startLabel,endLabel))

      # Select wanted columns from xmap and smap
      xmap_t1 <- xmap1_gm %>% dplyr::select(1,QryContigID,RefcontigID,RefStartPos, RefEndPos, Confidence,n_alignedLabel_bf_sv,n_alignedLabel_af_sv,n_allLabel_bf_sv,n_allLabel_af_sv,startLabel,endLabel,NumSites)
      smap_t1 <- smap[entry,] %>% dplyr::mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence,svSize.smap=svSize)%>% dplyr::select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap,svSize.smap)

      #   sv_gm_coverage <- full_join(smap_t1,xmap_t1)
      sv_gm_coverage <- plyr::rbind.fill(sv_gm_coverage,dplyr::full_join(smap_t1,xmap_t1,by="RefcontigID"))
    } else {
      # No genome map is found covering the SV region
      smap_t1 <- smap[entry,] %>% dplyr::mutate(RefcontigID=RefcontigID1,RefStartPos.smap=RefStartPos,RefEndPos.smap=RefEndPos,Confidence.smap=Confidence,svSize.smap=svSize) %>% dplyr::select(SmapEntryID,RefcontigID,RefStartPos.smap,RefEndPos.smap,Confidence.smap,svSize.smap)
      sv_gm_coverage <- plyr::rbind.fill(sv_gm_coverage,smap_t1)
    }
  }
  return(sv_gm_coverage)
}
