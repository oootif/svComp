#' A Function to read bed into a dataframe
#'
#' @param bed noChr
#' @return dataframe for a bed file with first 5 columns
#' @keywords bed
#' @export
#' @examples
#' #readbed_svSize(bed_filename)
#' # remove string "chr" from 1st column
#' #readbed_svSize(bed_filename, noChr=TRUE)
readbed_svSize <- function(filename, noChr = FALSE, commentChar="#") {
  bed <- NULL
  try( {

    bed <- read.table(filename, comment.char=commentChar, header=FALSE, stringsAsFactors=FALSE, fill=TRUE)

    if (ncol(bed)>=5) {
      bed <- dplyr::select(bed,1:5)
      colnames(bed) <- c( "chr", "start", "end", "id", "svSize")
    } else {
      print("ERROR: Need a bed file with 5 columns. The 4th column is unique ID. The 5th column is the SV size.")
    }

    if (noChr == TRUE){ # if there is "chr" in the chromosome name column, remove "chr"
      bed <- dplyr::mutate(bed,chr=gsub("chr","",chr))
    }
  } ) #try
  return(bed)
} #readbed_svSize
