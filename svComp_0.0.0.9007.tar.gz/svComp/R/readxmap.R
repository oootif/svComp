#' A Function to read xmap into a dataframe
#'
#' @param xmap filename
#' @return dataframe for a xmap
#' @keywords xmap
#' @export
#' @examples
#' #readxmap(xmap_filename)
#' ##TODO: optimize readxmap, so it's not too column number dependent

readxmap <- function(filename) {
  xmap <- NULL
  try( {

    xmap <- read.table(filename, comment.char="#", header=FALSE, stringsAsFactors=FALSE, nrows=50, sep="\t")

    if (ncol(xmap) == 10) {
      colnames(xmap) <- c("XmapEntryID", "QryContigID", "RefcontigID",
                          "QryStartPos", "QryEndPos", "RefStartPos", "RefEndPos",
                          "Orientation", "Confidence", "HitEnum")
    } else if (ncol(xmap) == 14) { #121514 - new columns
      colnames(xmap) <- c("XmapEntryID", "QryContigID", "RefcontigID",
                          "QryStartPos", "QryEndPos", "RefStartPos", "RefEndPos",
                          "Orientation", "Confidence", "HitEnum",
                          "QryLen","RefLen","LabelChannel","Alignment") #121514
    }

    class(xmap$QryContigID) <- "character" #change QryContigID to "character" to prevent overflow

    xmap <- as.data.frame(scan(filename, what=xmap, comment.char="#", quiet=TRUE),stringsAsFactors=FALSE)

  } ) #try
  return(xmap)
} #readxmap
