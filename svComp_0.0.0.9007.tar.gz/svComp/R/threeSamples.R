
# For 3 samples comparison

# Read in the result files from bedtools multiinter of 3 samples
# Ran by: bedtools multiinter -i Child.bed Father.bed Mother.bed -names D F M -header > overlap_ins.multiinter
# Then read overlap_ins.multiinter into dataframe, get_3_venn_counts(dataframe)
#' @export
get_3_venn_counts <- function(multiinter){
  Child <- filter(multiinter,D==1 & F==0 & M==0) %>% nrow()
  Father <- filter(multiinter,D==0 & F==1 & M==0) %>% nrow()
  Mother <- filter(multiinter,D==0 & F==0 & M==1) %>% nrow()
  ChildFather <- filter(multiinter,D==1 & F==1 & M==0) %>% nrow()
  ChildMother <- filter(multiinter,D==1 & F==0 & M==1) %>% nrow()
  FatherMother <- filter(multiinter,D==0 & F==1 & M==1) %>% nrow()
  ChildFatherMother <- filter(multiinter,D==1 & F==1 & M==1) %>% nrow()
  #venn3 <- rbind(Child,Father,Mother,ChildFather,ChildMother,FatherMother,ChildFatherMother)
  venn3 <- c(Child=Child,Father=Father,Mother=Mother,"Child&Father"=ChildFather,"Child&Mother"=ChildMother,"Father&Mother"=FatherMother,"Child&Father&Mother"=ChildFatherMother)
  #v <- venneuler(venn3)
  return(venn3)
}

# This function calculate the de novo rate and non-de-novo rate for deletion and insertion. No size stratification.
# Input: a dataframe contains SmapEntryID, GenotypeGroup, (SV)Type, Confidence; a sv size threshold (bp) (eg. 2000)
# Output: dataframe of de novo rate and count for deletion and insertion
#' @export
get_de_novo_rate_trio <- function(df,svSizeThreshold=0){
  all <-count_SV(df %>% filter(svSize.smap>svSizeThreshold))
  denovo <-count_SV(df %>% filter(denovo==1,svSize.smap > svSizeThreshold))
  nondenovo <-count_SV(df %>% filter(denovo==0,svSize.smap > svSizeThreshold))
  del_nondenovo <- as.numeric(nondenovo[1,2])/as.numeric(all[1,2])
  del_denovo <- as.numeric(denovo[1,2])/as.numeric(all[1,2])
  ins_nondenovo <- as.numeric(nondenovo[2,2])/as.numeric(all[2,2])
  ins_denovo <- as.numeric(denovo[2,2])/as.numeric(all[2,2])
  del_nondenovo_perc <- percent0(del_nondenovo)
  del_denovo_perc <- percent0(del_denovo)
  ins_nondenovo_perc <- percent0(ins_nondenovo)
  ins_denovo_perc <- percent0(ins_denovo)

  deletion <- c("denovo"=as.numeric(denovo[1,2]),
                "denovo_percent"=del_denovo_perc,
                "nonodenovo"=as.numeric(nondenovo[1,2]),
                "nondenovo_percent"=del_nondenovo_perc,
                "all"=as.numeric(all[1,2])
  )

  insertion <- c("denovo"=as.numeric(denovo[2,2]),
                 "denovo_percent"=ins_denovo_perc,
                 "nonodenovo"=as.numeric(nondenovo[2,2]),
                 "nondenovo_percent"=ins_nondenovo_perc,
                 "all"=as.numeric(all[2,2])
  )
  outdf <- t(data.frame(deletion,insertion))
  return(outdf)
}
