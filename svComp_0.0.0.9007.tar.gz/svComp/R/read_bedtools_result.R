#' A Function to read bedtools intersect result
#'
#' @param output filename
#' @return dataframe
#' @keywords bed bedtools intersect
#' @export
#' @examples
#' #read_bedtools_result(cmap_filename)
read_bedtools_result <- function(bedtools_result){
  res <- read.table(bedtools_result, header=F, sep="\t", stringsAsFactors=F)
  return(res)
}
