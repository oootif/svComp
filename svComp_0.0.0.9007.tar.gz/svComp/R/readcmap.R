#' A Function to read cmap into a dataframe
#'
#' @param cmap filename
#' @return dataframe for a cmap
#' @keywords cmap
#' @export
#' @examples
#' #readcmap(cmap_filename)
#' ##TODO: optimize readcmap, so it's not too column number dependent

readcmap <- function(filename) {
  cmap <- NULL
  try({

    header0 <- readLines(filename,n=50)

    if (all(grepl("#",header0))) { #if all lines are comments, return NULL
      return(NULL)
    }

    header1 <- header0[regexpr("^#h", header0)>=0] #get column names

    header_splilt <- unlist(strsplit(header1,"\\s"))
    header <- tail(header_splilt,-1)

    cmap <- read.table(filename,comment.char="#",header=FALSE,stringsAsFactors=FALSE,nrows=50) #adjust nrows as needed

    ncols <- ncol(cmap)
    header <- head(header,ncols)

    colnames(cmap) <- header

    class(cmap$CMapId) <- "character"

    cmap <- as.data.frame(scan(filename,what=cmap,comment.char="#",quiet=TRUE),stringsAsFactors=F)

  }) # try

  return(cmap)

} #readcmap
