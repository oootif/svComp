#' cut_GM_by_fixed_length
#'
#' This function allows you to cut genome map into specific length
#' @param cmap_file output_prefix disire_length RefAligner
#' @return string output.stdout file
#' @keywords cut refaligner
#' @export
# @examples
# #For example, if you want a list of genome maps with average 1Mb length
# #cut_GM_by_fixed_length(cmap_file="/home/users/jshi/data/ZM_BspQI/Merged_molecules/output/contigs/exp_refineFinal1/EXP_REFINEFINAL1.cmap",
# #                      output="/home/users/tliang/data/20150921_maize_B73/cut_GM_1Mb/b73_cut1Mb_tmp",
# #                       disire_length=1000000)

cut_GM_by_fixed_length <- function(cmap_file, output, disire_length, REFALIGNER="/home/users3/csecol/software/v2.4/tools/RefAligner"){
  cmap <- readcmap(cmap_file)
  increament <- max(as.numeric(unlist(unique(cmap[,1])))) # make the maximum genome map id as the ID increment, to prevent overriding GM ID
  gm_id_length <- unique(cmap[,1:2])
  gm_id_length1 <- gm_id_length %>% mutate(cuts=floor(ContigLength/disire_length)) %>% filter(cuts>0)
  result=NULL
  gm_id_length2 <- sapply(1:nrow(gm_id_length1), function(i) {paste(gm_id_length1[i,1],get_periodic_num_list(gm_id_length1[i,3],length=disire_length))})
  length_command <- paste0(gm_id_length2, collapse=" ")
  command = paste(REFALIGNER,"-f -i", cmap_file,"-merge -minsites 0 -o",output, "-stderr -stdout -break", increament, length_command)
  try(system(command))
  return(paste0(output,".stdout"))
}
