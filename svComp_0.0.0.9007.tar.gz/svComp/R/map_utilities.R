

## CMAP related ##
# Get number of labels for a CMAP ID.
#' @export
get_numSites_df <- function(incmap) {
  cmap_numSites <- incmap %>% select(CMapId,NumSites) %>% unique
  return(cmap_numSites)
}

# get_periodic_num_list(3, 1000000)
# return: 1000000 2000000 3000000
#' @export
get_periodic_num_list <- function(frequency,length){
  result <- NULL
  for (i in 1:frequency){
    length1 <- paste0(length*i/1000,".0")
    result <- paste(result, length1)
  }
  return(result)
}

#' @export
get_num_of_genome_map <- function(filename) {
  header0 <- readLines(filename,n=100) #find header lines
  header <- header0[regexpr("^#",header0)>=0]
  line_consensus <- header[grepl("Consensus Maps", header)]
  line_consensus1 <- as.numeric(unlist(strsplit(line_consensus,"\\t"))[2])
  return(line_consensus1)
}

#' @export
readcmap1 <- function(filename) {
  con1 <- pipe(paste0("head -n 100 ",filename," | cut -f1-9")) #cut has to finish what it's doing first
  cmap <- read.table(con1,comment.char="#",header=FALSE,stringsAsFactors=FALSE,fill=TRUE,col.names=1:9,nrows=100) #20150324 EL - format change

  potential_colnames <- c("CMapId","ContigLength","NumSites",
                          "SiteID","LabelChannel","Position",
                          "StdDev","Coverage","Occurrence","ChimScore",
                          "GmeanSNR","lnSNRsd","SNR")

  ncols <- ncol(cmap)
  cmap_colnames <- potential_colnames[1:ncols]

  colnames(cmap) <-cmap_colnames

  class(cmap$CMapId) <- "character"

  con2 <- pipe(paste0("cut -f1-9 ",filename))
  cmap <- as.data.frame(scan(con2,what=cmap,comment.char="#",quiet=TRUE),stringsAsFactors=F)
  close(con2)

  return(cmap)
}

## SMAP related ##

# Get SV size. Input a smap dataframe, output a smap dataframe with 1 extra column for SV size
#' @export
get_sv_size <- function(smap){
  smap_w_sv_size <- (dplyr::mutate(smap,svSize=abs((RefEndPos-RefStartPos)-(QryEndPos-QryStartPos))))
  return(smap_w_sv_size)
}

# Input a smap dataframe, with specific SV type, and minimum SV size. Returns an new smap dataframe
# eg. get_sv_type_minlen(smap,"deletion",1000)
#' @export
get_sv_type_minlen <- function(smap, svType, minLen=0,minConf=0, minConfNew=0){
  if(!exists('svSize', where=smap)){
    smap <- get_sv_size(smap)
  }
  if ("Confidence_1" %in% colnames(smap)){
    smap_filtered <- dplyr::filter(smap, Type==svType & svSize >= minLen & Confidence >= minConf & Confidence_1 >= minConfNew)
  }else{
    smap_filtered <- dplyr::filter(smap, Type==svType & svSize >= minLen & Confidence >= minConf)
  }
  return(smap_filtered)
}

# Input a smap dataframe, and minimum SV size. Returns an new smap dataframe for InDel SV only
#' @export
get_indel_minlen <- function(smap, minLen=0,minConf=0){
  if(!exists('svSize', where=smap)){
    smap <- get_sv_size(smap)
  }
  smap_filtered <- dplyr::filter(smap, (Type=="deletion" | Type=="insertion") & (svSize >= minLen) & (Confidence >= minConf))
  return(smap_filtered)
}

#' @export
get_overall_rates <- function(bedtools_output,mode="wao") { # default 1 bp overlap
  overall_rates <- parseIntersect(bedtools_output,mode)
  return(overall_rates)
} #get_overall_rates

#' @export
stratifySVs <- function(indata, binList) {
  bins <- binList
  #bins <- c(2000,5000,20000) # create bins [2000,5000),[5000,20000)
  intervals_data <- findInterval(indata,bins)
  return(intervals_data)
} #stratifySVs

#' @export
get_stratified_rates <- function(data, mode="wao", binList) { # default 1 bp overlap
  stratified <- stratifySVs(data[,5], binList)
  tmp <- by(data,stratified,parseIntersect,mode)
  tmp1 <- do.call(rbind,tmp)
  return(tmp1)
} #get_stratified_rates

#' @export
get_offspring_denovo_sv <- function(bedintersect_father, bedintersect_mother,ref_smap){

  offspring_DM_denovo <- dplyr::filter(bedintersect_mother,matches==0) # Select Daughter's SV that do not have a overlap with Mother's SV
  offspring_DF_denovo <- dplyr::filter(bedintersect_father,matches==0) # Select Daughter's SV that do not have a overlap with Father's SV
  inner_result <- dplyr::inner_join(offspring_DM_denovo,offspring_DF_denovo,by=c("a_id"="a_id")) #SVs that do Not appear in either parents
  offspring_denovo_sv <- dplyr::select(inner_result,1:5) # bed format, column in different order
  names(offspring_denovo_sv) <- c("chr","start","end","id","score") #Caution: wrong if there is a confidence score column
  smap_offspring_denovo_sv <- innerbed2smap(bed=offspring_denovo_sv,ref_smap=ref_smap)
  return(smap_offspring_denovo_sv)
}

#' @export
get_offspring_nondenovo_sv <- function(bedintersect_father, bedintersect_mother,ref_smap){

  offspring_DM_denovo <- dplyr::filter(bedintersect_mother,matches!=0) # Select Daughter's SV that have a overlap with Mother's SV
  offspring_DF_denovo <- dplyr::filter(bedintersect_father,matches!=0) # Select Daughter's SV that have a overlap with Father's SV
  inner_result <- dplyr::inner_join(offspring_DM_denovo,offspring_DF_denovo,by=c("a_id"="a_id")) #SVs that do Not appear in either parents
  offspring_denovo_sv <- dplyr::select(inner_result,1:5) # bed format, column in different order
  names(offspring_denovo_sv) <- c("chr","start","end","id","score") #Caution: wrong if there is a confidence score column
  smap_offspring_denovo_sv <- innerbed2smap(bed=offspring_denovo_sv,ref_smap=ref_smap)
  return(smap_offspring_denovo_sv)
}

#' @export
innerbed2smap <- function(bed,ref_smap){
  smap_from_bed <- dplyr::filter(ref_smap,SmapEntryID%in%(bed$id))
  return(smap_from_bed)
}

# If a bed file came from a smap, it can go back to the smap format.
# If the bed doesn't have smap coordinates matched, add buffer to search for a nearby SV smap.
#' @export
get_smap_from_bed <- function(bed, smap, buffer=0, getSize=TRUE){
  smap_tmp4 = NULL
  for (i in 1:nrow(bed)){
    smap_tmp <- smap %>%
      dplyr::filter(RefcontigID1==bed[i,1], RefStartPos<=(bed[i,3]-buffer), RefEndPos>=(bed[i,2]+buffer)) %>%
      dplyr::mutate(bed_coord=bed[i,1], puiSV_coord=paste0(bed[i,2],"-",bed[i,3]), pui_id=bed[i,4], pui_svSize=bed[i,5])
    if(getSize ==TRUE){
      smap_tmp2 <- get_sv_size(smap_tmp)
    } else {
      smap_tmp2 <- smap_tmp
    }
    smap_tmp3 <- smap_tmp2 %>% mutate(svSizeRatio=round(pmin(pui_svSize,svSize)/pmax(pui_svSize,svSize),3), index=i)
    smap_tmp4 <- rbind(smap_tmp4,smap_tmp3)
  }
  return(smap_tmp4)
}


## XMAP related ##

# Split a list of alignment from XMAP into a matrix of 2 columns. 1 for ref ID, 1 for qry ID, forms a pair of alignment.
#' @export
split_alignment <- function(alignment) {
  alignment_split <- unlist(strsplit(alignment,split="\\)\\(")) #split the brackets
  alignment_split <- lapply(alignment_split,function(alignment) {gsub("\\(","",alignment)}) #remove "("
  alignment_split <- lapply(alignment_split,function(alignment) {gsub("\\)","",alignment)}) #remove ")"
  alignment_split <- lapply(alignment_split,function(alignment) {as.numeric(strsplit(alignment,",")[[1]])}) #split qry and ref
  alignment2 <- do.call(rbind,alignment_split)

  #alignment_split <- lapply(alignment_split,function(alignment) {do.call(rbind,alignment)}) #put in dataframe
  #alignment <- do.call(rbind,alignment_split)
  colnames(alignment2) <- c("ref","qry")
  alignment3 <- as.data.frame(alignment2,stringsAsFactors=F)

  return(alignment3)
}

#' @export
add_numSites_to_xmap <- function(xmap,qcmap){
  numSites <- get_numSites_df(qcmap)
  xmap_numSites <- (dplyr::inner_join(xmap, numSites ,by=c("QryContigID"="CMapId")))
  return(xmap_numSites)
}


## BED related ##

# Add buffer length to both sides of the bed region, keep bed file format, keep all columns
#' @export
bed_add_buffer <- function(bed, buffer){
  bed_w_buffer <- dplyr::mutate(bed, RefStartPos=pmax(0,RefStartPos-buffer),RefEndPos=RefEndPos+buffer)
  return(bed_w_buffer)
}

# Add buffer to both sides of the 2nd & 3rd columns. Only return the first 5 columns of the bed file.
#' @export
add_buffer <- function(bed,buffer=20000){
  names(bed)[2]="start1"
  names(bed)[3]="stop1"
  newbed <- bed %>% mutate(start=pmax(0,as.integer(start1)-buffer),stop=as.integer(stop1)+buffer) %>%
    select(1,start,stop,4,5)
  return(newbed)
}

# Take percentage of a number. Return a string with % sign.
#' @export
percent <- function(x, digits = 2, format = "f", ...) {
  paste0(formatC(100 * x, format = format, digits = digits, ...), "%")
}

# Take percentage of a number. Return a number without % sign
#' @export
percent0 <- function(x, digits = 2, format = "f", ...) {
  x_1 <- formatC(100 * x, format = format, digits = digits, ...)
  x_2 <- as.numeric(x_1)
  return(x_2)
}

