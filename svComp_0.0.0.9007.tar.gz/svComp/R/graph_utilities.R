## Graph ##

# Make barplot for sensitivity of query
# input 2 bedTools intersect result data frame, size of bins, name of bins
# For example
# size_bin <- c(0, 500, 1000, 2000, 5000, 10000,15000,20000,30000,50000,70000,100000,150000,200000,300000,500000,1500000)
# bin_names <- c("0-0.5","0.5-1","1-2","2-5","5-10","10-15","15-20","20-30","30-50","50-70","70-100","100-150","150-200","200-300","300-500","500+")
# bedintersect_qry : list of number, sv sizes
# bedintersect_ref: list of number, sv sizes (ran bedtools intersect with the same -a bed1 file)
#' @export
barplot_sensitivity <- function(bedintersect_qry,bedintersect_ref, size_bin,bin_names,label_height=-1,label_pos=0,ylab=NULL) {
  bedintersect_qry <- as.numeric(bedintersect_qry)
  bedintersect_ref <- as.numeric(bedintersect_ref)
  hist_size_and_bin_qry <- hist(bedintersect_qry, breaks=size_bin,plot=FALSE)
  hist_size_and_bin_ref <- hist(bedintersect_ref, breaks=size_bin,plot=FALSE)
  label_shift1 <- c(-0.1, -0.125, -0.15)
  label_shift <- label_shift1 + label_pos
  label_height<- -1
  label_shift_zero <- rev(label_shift) * label_height
  bplot1 <- barplot(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count,names.arg=bin_names,ylim = c(0,1),xlab="SV size (kb)", ylab=ylab,width=0.5) # Limit Y axit to be 0-1 for sensitivity
  # bplot1 <- barplot(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count,names.arg=bin_names,ylim = c(0,1), ylab=ylab,width=0.5,xaxt="n")

  # Re-label x-axis
  # text(cex=1, x=bplot1, y=-1.25,labels=bin_names, srt=45,pos=1,xpd=TRUE)

  # Draw numerator
  text(x=bplot1,y=ifelse(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count>label_shift_zero[1], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift[1], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift_zero[1]),labels=hist_size_and_bin_qry$count,cex=1)

  # Draw line in factor
  text(x=bplot1,y=ifelse(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count>label_shift_zero[1], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift[2], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift_zero[2]),labels="-----",cex=1)

  # Draw denominator
  text(x=bplot1,y=ifelse(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count>label_shift_zero[1], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift[3], hist_size_and_bin_qry$count/hist_size_and_bin_ref$count+label_shift_zero[3]),labels=hist_size_and_bin_ref$count,cex=1)
  size_stratify_count <- rbind("overlapped"=hist_size_and_bin_qry$count, "total"=hist_size_and_bin_ref$count, "overlapped_percent"=percent0(hist_size_and_bin_qry$count/hist_size_and_bin_ref$count))

  # Add overlap count for all SV column
  count_qry <- as.numeric(length(bedintersect_qry))
  count_ref <- as.numeric(length(bedintersect_ref))
  percent_all <- percent0(count_qry/count_ref)
  count_column <- c(count_qry,count_ref,percent_all)
  size_stratify_count_nAll <- cbind(size_stratify_count,count_column)
  colnames(size_stratify_count_nAll) <- c(bin_names,"All")

  size_stratify_count_nAll <- t(size_stratify_count_nAll)
  return(size_stratify_count_nAll)
}

# Make scatter plot with a bedTools intersect result data frame, for SV size comparison
#' @export
scatterPlot_svSize <- function(bedtools_intersect_result, xlim=NULL, ylim=NULL, xlab=NULL,ylab=NULL,main=NULL){
  plot(bedtools_intersect_result$a_score, bedtools_intersect_result$b_score,xlim=xlim,ylim=ylim,xlab=xlab,ylab=ylab,main=main) # Show all overlap pairs, ref SV(a_score) is not unique
  abline(a=0,b=.5,col="red")
  abline(a=0,b=2,col="red")
  abline(a=0,b=1,col="blue")
}

# Draw a line with x,y coordinates, color
#' @export
draw_line<- function(x1,x2,y1,y2,xshift=0,yshift=0, color="blue"){ #Draw line with x,y coordinates,shift value,color
  x1s = x1+xshift
  x2s = x2+xshift
  y1s = y1+yshift
  y2s = y2+yshift
  lines(c(x1s,x2s),c(y1s,y2s),lwd=5,col=color)
}

# Draw histogram to show SV size distribution. One full distribution, one zoom-in to 95% of the SV. Input: smap dataframe
#' @export
plot_svSize_distribution <- function(smap,title="SV Size Distribution"){
  require(ggplot2)
  require(gridExtra)
  if(!exists('svSize', where=smap)){
    smap <- get_sv_size(smap)
  }
  par(mfrow=c(2,1))
  x_max = max(smap$svSize)
  bin.width=x_max/500 # set default bin size to be 1/500 of the total x axis
  hist_all <- ggplot(smap,aes(svSize))+ geom_histogram(binwidth=bin.width)+ xlab("All SV size (bp)") + ylab("SV counts")

  x_zoomin = quantile(smap$svSize, .95) # Set zoom in, default show 95% of all SV
  bin.width_zoomin=x_zoomin/100 # set default bin size to be 1/100 of the zoom-in x axis
  hist_zoomin <- ggplot(smap,aes(svSize)) + geom_histogram(binwidth=bin.width_zoomin) + coord_cartesian(xlim = c(0,x_zoomin))+ xlab("Zoom-in SV size (bp)") + ylab("SV counts")

  grid.arrange(hist_all, hist_zoomin, nrow=2, ncol=1, top=textGrob(title,gp=gpar(fontsize=14,font=2)))
  return(hist_zoomin)
}

# Draw histogram to show SV size distribution. One full distribution, one zoom-in to 95% of the SV. Input: smap dataframe
#' @export
plot_hist_distribution <- function(numVec,title="Distribution"){
  require(ggplot2)
  require(gridExtra)
  numVec.df <- data.frame(numVec)
  names(numVec.df) <- "numbers"
  par(mfrow=c(2,1))
  x_max = max(numVec.df)
  bin.width=x_max/500 # set default bin size to be 1/500 of the total x axis
  hist_all <- ggplot(numVec.df,aes(numbers))+ geom_histogram(binwidth=bin.width)+ xlab("All SV size (bp)") + ylab("SV counts")

  x_zoomin = quantile(numVec.df$numbers, .95) # Set zoom in, default show 95% of all SV
  bin.width_zoomin=x_zoomin/100 # set default bin size to be 1/100 of the zoom-in x axis
  hist_zoomin <- ggplot(numVec.df,aes(numbers)) + geom_histogram(binwidth=bin.width_zoomin) + coord_cartesian(xlim = c(0,x_zoomin))+ xlab("Zoom-in SV size (bp)") + ylab("SV counts")

  grid.arrange(hist_all, hist_zoomin, nrow=2, ncol=1, top=textGrob(title,gp=gpar(fontsize=14,font=2)))
  return(hist_zoomin)
}

# Make coverage plot (bar plot), given *_r.cmap file path. Can specific x and y axis range, and color. Based on Coverage and Position column in rcmap
# coverage_plot("/home/users/tliang/data/20160406_NA12878_ulhg38hap/output/contigs/alignmolvref/merge/alignmolvref_contig22.xmap", xlim=c(1234567,2345678))
#' @export
coverage_plot <- function(rcmap_filename, ylim=NULL,xlim=NULL, col="black"){
  rcmap <- readcmap1(rcmap_filename)
  plot(select(rcmap,Position,Coverage),col=col,ylim=ylim,xlim=xlim,type='h')
}
