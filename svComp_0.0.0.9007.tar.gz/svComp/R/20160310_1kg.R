#20160310 EL - 1KG analysis

#rm(list=ls())

# options(scipen = 999)

# source("http://bioconductor.org/biocLite.R")
# biocLite("quantsmooth")
# library(quantsmooth)
#
# source("/home/users/elam/rscripts/overlap.R")
# source("/home/users/elam/rscripts/readmaps.R")
# source("/home/users/elam/rscripts/smap_comparison.R") #main script to compare two SV lists

#filering of smap list by sample based on smap names
filter_by_sample <- function(smap_files,sample_list) {
  match_indices <- lapply(sample_list,function(pattern) grep(pattern,smap_files))
  match_indices <- sort(unique(unlist(match_indices)))

  smap_files_filtered <- smap_files[match_indices]

  return(smap_files_filtered)
}

#filering of smap list by enzyme based on smap names
filter_by_enzyme <- function(smap_files,enzyme_list) {
  match_indices <- lapply(enzyme_list,function(pattern) grep(pattern,smap_files))
  match_indices <- sort(unique(unlist(match_indices)))

  smap_files_filtered <- smap_files[match_indices]

  return(smap_files_filtered)
}

#making ideogram plot (modified from code from quantsmooth)
#' @export
prepareGenomePlot <- function (chrompos = NULL, cols = "grey50", paintCytobands = FALSE,
          bleach = 0, topspace = 1, organism, sexChromosomes = FALSE,
          units = "hg19", plot_flag=T ,...)
{
  cytobandWidth <- 0.075
  par(mar = c(1, 4, 2, 3) + 0.1)
  if (!missing(organism)) {
    organism <- match.arg(organism, c("hsa", "mmu", "rno"))
    chrom.n <- switch(organism, hsa = 22, mmu = 19, rno = 20)
    if (is.null(chrompos)) {
      chroms = c(1:chrom.n, if (sexChromosomes) c(98, 99) else NULL)
      chrnames = characterCHR(chroms, "chr")
      mapinfo = rep(0, length(chroms))
      chrompos = cbind(CHR = chroms, MapInfo = mapinfo)
      rownames(chrompos) <- chrnames
    }
    chrs2 <- factor(quantsmooth::numericCHR(chrompos[, "CHR"]), levels = c(1:chrom.n,
                                                              if (sexChromosomes) c(98, 99) else NULL))
    if (organism == "hsa")
      lens <- lengthChromosome(levels(chrs2), units = units)
    else lens <- sapply(split(chrompos[, "MapInfo"], chrs2),
                        function(x) max(c(0, x)))
    names(lens) <- characterCHR(names(lens))
    cols <- rep(cols, length.out = length(lens))
    names(cols) <- names(lens)
    dwidth <- NULL
    for (i in 1:(chrom.n%/%2)) dwidth[i] <- lens[i] + lens[chrom.n +
                                                             1 - i]
    if (chrom.n%%2 == 1)
      dwidth <- c(dwidth, lens[chrom.n%/%2 + 1])
    if (sexChromosomes)
      dwidth <- c(dwidth, lens["X"] + lens["Y"])
    maxdwidth <- max(dwidth) * 1.05
    leftrow <- c(if (sexChromosomes) "X" else NULL, ((chrom.n +
                                                        1)%/%2):1)
    rightrow <- c(if (sexChromosomes) "Y" else NULL, if (chrom.n%%2 ==
                                                           1) "" else NULL, ((chrom.n + 1)%/%2 + 1):chrom.n)

    if (plot_flag) { #20160310 EL - manually added to control whether to plot
      plot(c(0, maxdwidth), c(0.5, 0.5 + length(dwidth) + topspace),
           type = "n", ylab = "Chromosome", xlab = "", axes = FALSE,
           las = 2, ...)
      axis(2, c(1:length(dwidth)), characterCHR(leftrow), las = 2)
      axis(4, c(1:length(dwidth)), characterCHR(rightrow),
           las = 2)

      if (paintCytobands && organism == "hsa") {
        for (i in 1:length(dwidth)) {
          if (lens[leftrow[i]] > 0)
            paintCytobands(leftrow[i], c(0, i + cytobandWidth/2),
                           units, width = cytobandWidth, length.out = lens[leftrow[i]],
                           legend = FALSE, bleach = bleach)
          if (rightrow[i] != "" && lens[rightrow[i]] >
                0)
            paintCytobands(rightrow[i], c(maxdwidth - lens[rightrow[i]],
                                          i + cytobandWidth/2), "bases", width = cytobandWidth,
                           length.out = lens[rightrow[i]], legend = FALSE,
                           bleach = bleach)
        }
      }
      else {
        for (i in 1:length(dwidth)) {
          lines(c(0, lens[leftrow[i]]), c(i, i), col = cols[leftrow[i]],
                lwd = 2)
          if (rightrow[i] != "")
            lines(c(maxdwidth - lens[rightrow[i]], maxdwidth),
                  c(i, i), col = cols[rightrow[i]], lwd = 2)
        }
      }
    }

    dchrompos <- matrix(0, nrow = nrow(chrompos), ncol = 2,
                        dimnames = list(rownames(chrompos), c("CHR", "MapInfo")))

    for (i in 1:length(rightrow)) if (rightrow[i] != "") {
      probes <- characterCHR(chrompos[, "CHR"]) == rightrow[i]
      dchrompos[probes, 2] <- chrompos[probes, "MapInfo"] +
        maxdwidth - lens[rightrow[i]]
      dchrompos[probes, 1] <- i
    }
    for (i in 1:length(leftrow)) {
      probes <- characterCHR(chrompos[, "CHR"]) == leftrow[i]
      dchrompos[probes, 2] <- chrompos[probes, "MapInfo"]
      dchrompos[probes, 1] <- i
    }
  }
  else { #missing organism
    chrs2 <- factor(quantsmooth::numericCHR(chrompos[, "CHR"]))
    lens <- sapply(split(chrompos[, "MapInfo"], chrs2), max)
    m <- length(lens)
    cols <- rep(cols, length.out = m)
    maxdwidth <- max(lens)
    plot(c(0, maxdwidth), c(0.5, m + 0.5 + topspace), type = "n",
         ylab = "Chromosome", xlab = "", axes = FALSE, las = 2,
         ...)
    axis(2, c(m:1), characterCHR(names(lens)), las = 2)
    for (i in 1:m) lines(c(0, lens[i]), c(m + 1 - i, m +
                                            1 - i), col = cols[as.numeric(names(lens))], lwd = 2)
    dchrompos <- chrompos
    dchrompos[, 1] <- m + 1 - as.numeric(chrs2)
  }

  return(dchrompos)
}

#filter smap entries by type, confidence, and size
filter_sv <- function(smap,type,conf,sv_size) {
  stopifnot(length(type)==1)
  stopifnot(length(conf)==1)

  smap_filtered <- smap[smap[,"Type"]==type,] #filter by type
  smap_filtered1 <- smap_filtered[smap_filtered[,"Confidence"]>conf,] #filter by confidence score

  smap_filtered1[,"size"] <- (smap_filtered1$QryEndPos-smap_filtered1$QryStartPos)-(smap_filtered1$RefEndPos-smap_filtered1$RefStartPos)
  smap_filtered2 <- smap_filtered1[abs(smap_filtered1[,"size"])>sv_size,] #filter by sv size

  return(smap_filtered2)
}

#read smap and do basic filtering
process_smap <- function(smap,type) {
  print(smap)

  smap <- readSMap(smap) # Caution: readsmap is used in svComp package
  smap <- smap[smap[,"RefcontigID1"]%in%(1:24),]
  smap_filtered <- filter_sv(smap,type=type,conf=3,sv_size=0)

  return(smap_filtered)
}


#make ideogram plot
#' @export
plot_ideogram_bed <- function(beds,plot_title='',color,units="hg19") {
  bed <- lapply(1:length(beds),function(i) {

    bed <- beds[[i]]

    #construct genomic positions
#     stopifnot(bed[,"RefcontigID1"]==bed[,"RefcontigID2"])
    chr <- bed[,1] #chromosomes
    chr[chr==23] <- "X"
    chr[chr==24] <- "Y"
    start <- bed[,2] #position on chromosome
    end <- bed[,3]
    mid <- (start+end)/2

    if (i==1) {
      chrompos <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=start),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units=units,plot_flag=T,main=plot_title)

    } else {
      chrompos <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=start),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units=units,plot_flag=F)
    }
    chrompos1 <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=end),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units=units,plot_flag=F)
    chrompos2 <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=mid),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units=units,plot_flag=F)

    points(chrompos2[,2],chrompos2[,1]+(0.1*i),pch="|",col=color[i],cex=0.4)
  })
}


#make ideogram plot
plot_smaps_all <- function(smaps,plot_title='',color) {
  smaps <- lapply(1:length(smaps),function(i) {

    smap <- smaps[[i]]

    #construct genomic positions
    stopifnot(smap[,"RefcontigID1"]==smap[,"RefcontigID2"])
    chr <- smap[,"RefcontigID1"] #chromosomes
    chr[chr==23] <- "X"
    chr[chr==24] <- "Y"
    start <- smap[,"RefStartPos"] #position on chromosome
    end <- smap[,"RefEndPos"]
    mid <- (start+end)/2

    if (i==1) {
      chrompos <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=start),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units="hg38",plot_flag=T,main=plot_title)

    } else {
      chrompos <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=start),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units="hg38",plot_flag=F)
    }
    chrompos1 <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=end),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units="hg38",plot_flag=F)
    chrompos2 <- prepareGenomePlot(data.frame("CHR"=chr,"MapInfo"=mid),paintCytobands=TRUE,sexChromosomes=TRUE,organism="hsa",units="hg38",plot_flag=F)

    points(chrompos2[,2],chrompos2[,1]+(0.1*i),pch="|",col=color,cex=0.4)
  })
}

#make basic per-chromosome plot
plot_smaps_per_chr <- function(smaps,plot_title='',color,chr=1) {

  plot(0,xlim=c(0,as.numeric(lengthChromosome(chr,"hg38"))),ylim=c(1,3),
       type="n",xlab="Genomic position (bp)",ylab="",main=paste0("chromosome",chr),bty='n')

  all_midpoints <- lapply(1:length(smaps),function(i) {
    smap <- smaps[[i]]

    smap <- smap[smap[,"RefcontigID1"]==chr,]
    rect(smap[,"RefStartPos"],i*0.5+0.5,smap[,"RefEndPos"],i*0.5+0.7)

    midpoints <- (smap[,"RefStartPos"]+smap[,"RefEndPos"])/2

    return(midpoints)
  })
  all_midpoints <- unlist(all_midpoints)

#   hist(all_midpoints,breaks=100)

#   paintCytobands(chrom=chr,pos=c(0,2.5),units="hg38",width=0.1,orientation="h",legend=T,cex.leg=0.5,bleach=0.5)
}

#wrapper for plotting SVs
process_sv <- function(sv_dir) {
  #smap_files <- dir(sv_dir,".smap")
  #smap_files <- dir(sv_dir,"EXP_REFINEFINAL1.smap")
  smap_files <- dir(sv_dir,"minlen0mincon3.smap")

  smap_files <- paste0(sv_dir,smap_files)

  smap_files <- filter_by_sample(smap_files,c("PUR"))
  smap_files <- filter_by_sample(smap_files,c("BspQI"))

  smaps <- lapply(smap_files,process_smap,type="deletion")
  plot_smaps_all(smaps,"PUR deletions","red")
  smaps <- lapply(smap_files,process_smap,type="insertion")
  plot_smaps_all(smaps,"PUR insertions","blue")

#   plot_smaps_per_chr(smaps,"PUR insertions","blue")
}

check_alignref <- function(assemblies) {
  alignref <- paste0(assemblies,"/output/contigs/exp_refineFinal1/alignref_final/EXP_REFINEFINAL1.xmap")
  assemblies <- data.frame("assemblies"=assemblies,"alignref_flag"=file.exists(alignref),stringsAsFactors=F)

  err_files <- paste0(assemblies[,"assemblies"],"/output/contigs/exp_refineFinal1/alignref_final/EXP_REFINEFINAL1.err")
  err <- lapply(err_files,readerr)

  assemblies <- cbind(assemblies,do.call(rbind,err))

  return(assemblies)
}

check_assemblies <- function(assembly_dir) {
  assemblies <- dir(assembly_dir)
  assemblies <- paste0(assembly_dir,assemblies)

  assemblies <- assemblies[dir.exists(paste0(assemblies,"/output/"))]
  assemblies <- filter_by_sample(assemblies,c("PUR","CHS","YRI"))

  assemblies <- check_alignref(assemblies)
  filename <- "/home/users/elam/20160202_1kg/assembly_err_summary.txt"
  write.table(assemblies,file=filename,quote=F,sep="\t",row.names=F,col.names=T)
  print(assemblies)

}

do_one_sample <- function(input_sample) {
  dels <- lapply(input_sample,process_smap,type="deletion")
  ins <- lapply(input_sample,process_smap,type="insertion")

  del_comp <- do_comparison(dels[[1]],dels[[2]],type="deletion")
  del_comp1 <- do_comparison(dels[[2]],dels[[1]],type="deletion")

  ins_comp <- do_comparison(ins[[1]],ins[[2]],type="insertion")
  ins_comp1 <- do_comparison(ins[[2]],ins[[1]],type="insertion")

  outlist <- list("dels"=del_comp,
                  "dels1"=del_comp1,
                  "ins"=ins_comp,
                  "ins1"=ins_comp1)

  return(outlist)
}

compare_enzymes <- function(sv_dir,sample_name) {
  smap_files <- dir(sv_dir,".smap")
  smap_files <- paste0(sv_dir,smap_files)
  smap_files <- filter_by_sample(smap_files,sample_name)

  daughter <- filter_by_sample(smap_files,c("Daughter"))
  father <- filter_by_sample(smap_files,c("Father"))
  mother <- filter_by_sample(smap_files,c("Mother"))

#   print(daughter)
#   print(father)
#   print(mother)

  stopifnot(length(daughter)==2)
  stopifnot(length(father)==2)
  stopifnot(length(mother)==2)

  daughter <- do_one_sample(daughter)
  father <- do_one_sample(father)
  mother <- do_one_sample(mother)

  outlist <- list("daughter"=daughter,
                  "father"=father,
                  "mother"=mother)

  return(outlist)
}

summarize_overlap <- function(insample,population) {
  par(mfrow=c(3,2))

  all <- lapply(names(insample),function(sample_name) {
    tmp_sample <- insample[[sample_name]]

    summary <- lapply(names(tmp_sample),function(sv_type) {
      tmp_sv <- tmp_sample[[sv_type]]

      match_count <-sum(tmp_sv[,"overlap_flag"])
      all_count <- length(tmp_sv[,"overlap_flag"])
      fraction <- match_count/all_count

      outdf <- data.frame("sv_type"=sv_type,"match"=match_count,"all"=all_count,"fraction"=fraction,stringsAsFactors=F)

      if (sv_type=="dels") {
        plot(tmp_sv[,"size"],tmp_sv[,"raw_size"],pch=16,xlim=c(-100000,0),ylim=c(-100000,0),main=paste0(population," ",sample_name,": ",sv_type),xlab="BspQI size",ylab="BssSI size")
      } else {
        plot(tmp_sv[,"size"],tmp_sv[,"raw_size"],pch=16,xlim=c(0,100000),ylim=c(0,100000),main=paste0(population," ",sample_name,": ",sv_type),xlab="BspQI size",ylab="BssSI size")
      }
      abline(0,1,col=rgb(1,0,0,0.5))

      return(outdf)
    })
    names(summary) <- names(tmp_sample)
    summary <- do.call(rbind,summary)
    summary[,"sample"] <- sample_name

    return(summary)
  })
  names(all) <- names(insample)
  all <- do.call(rbind,all)

  return(all)
}

#look at SV calls across samples
#https://www.biostars.org/p/378/
#sv_dir <- "/home/users/ahastie/data/1000genomes/SV/"
#pdf("/home/users/elam/20160202_1kg/PUR_ideogram.pdf",width=12,height=8)
#process_sv(sv_dir)
#dev.off()

#stop()

# #look at alignref_final across samples
# assembly_dir <- "/home/users/ahastie/data/1000genomes/"
# check_assemblies(assembly_dir)

#look at BspQI vs BssSI (intersectBed and closestBed)
#sv_dir <- "/home/users/ahastie/data/1000genomes/SV/"
#pur <- compare_enzymes(sv_dir,"PUR")

#pdf("/home/users/elam/20160202_1kg/PUR_match_summary1.pdf",width=12,height=8)
#pur_summary <- summarize_overlap(pur,"PUR")
#dev.off()

#look at copy number profile across samples (not available for BssSI)
#look at segment length distribution (genome map and molecule level)
