#' A Function to call bedTools
#'
#' This function allows you to get number of label sites in the cmap. It is required to supply 2 bed files.
#' @param string string string string Parameters to call bedTools
#' @return dataframe of bedTools result
#' @keywords bedtools
#' @export
#bedTools("bedIntersect", "sv1.bed", "sv2.bed", "-wao")
#bedTools("bedIntersect", "sv1.bed", "sv2.bed", "-wao -r 50")
#bedTools(bed1=bedlist[[1]],bed2=bedlist[[2]], optString="-wao")
#TODO: update examples, and how to get smap to bed

bedTools<-function(functionstring="intersect",bed1,bed2,optString="-wao", sort=TRUE, bedpe=FALSE)
{
  #create temp files
  a.file<-tempfile()
  b.file<-tempfile()
  a_sort.file<-paste0(a.file,"_sort.bed")
  b_sort.file<-paste0(b.file,"_sort.bed")
  out = tempfile()
  options(scipen =99) # not to use scientific notation when writing out

  # Clean up bed data frame content
  if (sort){
    bed1 <- cleanup_bed(bed1)
    bed2 <- cleanup_bed(bed2)
  }

  if(!bedpe){
    bed1 <- bed1 %>% select(1:5)
    bed2 <- bed2 %>% select(1:5)
  }
  #write bed formatted dataframes to tempfile
  write.table(bed1,file=a.file,quote=F,sep="\t",col.names=F,row.names=F)
  write.table(bed2,file=b.file,quote=F,sep="\t",col.names=F,row.names=F)

  # sort bed files
  if (sort){
    sortBed(a.file, a_sort.file)
    sortBed(b.file, b_sort.file)
  } else{
    file.copy(a.file,a_sort.file)
    file.copy(b.file,b_sort.file)
  }
  # create the command string and call the command using system()
  command=paste("bedtools",functionstring,"-a",a_sort.file,"-b",b_sort.file,optString,">",out,sep=" ")
  try(system(command))
  result=read.table(out,header=F,stringsAsFactors=F)

  unlink(a.file);unlink(b.file);unlink(a_sort.file);unlink(b_sort.file)
  unlink(out)
  return(result)
}

# round number to integer, take floor if < 0.5, take ceiling if >= 0.5
#' @export
round_0.5 <- function(x) trunc(x+sign(x)*0.5)

cleanup_bed <- function(bed_df){
  bed_df[,2] = round_0.5(bed_df[,2])
  bed_df[,3] = round_0.5(bed_df[,3])
  if(length(colnames(bed_df))>=5 & is.numeric(bed_df[,5])){
    bed_df[,5] = round_0.5(bed_df[,5])
  } else {
    print(paste("Warning: bedfile score column is not numeric: ",bed_df[,5]))
  }
  return(bed_df)
}
# bed_file <- a.file
# out_bed_file <- a_sort.file
sortBed <- function(bed_file,out_bed_file){
  command=paste("sort -k1,1 -k2,2n",bed_file,">",out_bed_file)
  try(system(command,intern = TRUE,ignore.stderr = TRUE))
  return(out_bed_file)
}


# Add column names to bedTools intersects result
#'@export
add_names_bedintersect <- function(df){
  if(length(names(df))==11){
    names(df)<- c("a_chr","a_start","a_end","a_id","a_score","b_chr","b_start","b_end","b_id","b_score","matches")
  } else if(length(names(df))==9){
    names(df)<- c("a_chr","a_start","a_end","a_id","b_chr","b_start","b_end","b_id","matches")
  } else {
    print("Warning: Number of columns is not expected, please check bed file format")
  }
  return(df)
}

# bedTools_multi(bed_list=c("pur_daughter_bspqi_sm_sort_ins.bed", "pur_father_bspqi_sm_sort_ins.bed", "pur_mother_bspqi_sm_sort_ins.bed"),
#                   name_list=c("D", "F", "M"), optString="-header")
# bedTools_multi(functionstring="merge", bed_list=bedlist, optString="-d 25000 -c 4 -o count,collapse")

# Used to call multiinter, merge, function that can take 1 or more bed files
#' @export
bedTools_multi <-function(functionstring="multiinter",bed_list,name_list=list(),optString="-header",sort=TRUE)
{
  sorted.files <- NULL
  for (bed in bed_list){

    #create temp files
    a.file <- tempfile() # create bed file
    a_sort.file <- paste0(a.file,"_sort.bed") # create sorted bed file

    # Clean up bed data frame content
    if(sort){
      bed <- cleanup_bed(bed)
    }

    bed <- bed %>% select(1:5)

    #write bed formatted dataframes to tempfile
    write.table(bed,file=a.file,quote=F,sep="\t",col.names=F,row.names=F)

    # sort bed files
    if(sort){
      sortBed(a.file, a_sort.file)
    } else{
      file.copy(a.file, a_sort.file)
    }

    # join all the sorted bed files into one file list
    sorted.files <- cbind(sorted.files, a_sort.file)
    unlink(a.file)
  }

  out <- tempfile()
  options(scipen =99) # not to use scientific notation when writing out

  # create the command string and call the command using system()
  command=paste("bedtools",functionstring,"-i", paste(sorted.files,collapse=" "), optString,">",out,sep=" ")

  #   cat(command,"\n")
  try(system(command))

  result=read.table(out,header=F,stringsAsFactors=F)

  unlink(out)
  for (sortedbed in sorted.files){
    unlink(sortedbed)
  }
  return(result)
}




# NOT DONE
overlap_translocation_2sidesPerl <-function(smap1,smap2,buffer=50000,outputDir="./",removeResult=TRUE)
{
  #create temp files
  smap1.file<-tempfile()
  smap2.file<-tempfile()

  sampleName1 = "sample1"
  sampleName2 = "sample2"
  #output file: sample.1.vs.2.posWindow.25000.txt
  outputFile = file.path(outputDir,"sample_1_vs_sample_2",paste0("sample.1.vs.2.posWindow.",buffer,".txt"))

  #write smap formatted dataframes to tempfile
  write.table(smap1,file=smap1.file,quote=F,sep="\t",col.names=F,row.names=F)
  write.table(smap2,file=smap2.file,quote=F,sep="\t",col.names=F,row.names=F)

  # create the command string and call the command using system()
  command=paste("perl /home/users/apang/human/rady/scripts/trio_analysis/translocation_analysis/1_find_overlap_sample_1_2_trans.pl",
                smap1.file, smap2.file, buffer, outputDir, sampleName1, sampleName2, sep=" ")
  try(system(command))
  result=read.table(outputFile,header=TRUE,stringsAsFactors=FALSE)

  unlink(smap1.file);unlink(smap2.file)
  if(removeResult){
    unlink(outputFile)
  }
  return(result)
}

