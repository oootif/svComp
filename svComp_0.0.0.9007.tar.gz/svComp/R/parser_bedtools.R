# After bedtools merge, which groups the SVs that overlaps, or 5kb near each other into 1 SV region.
# Reduce the redundancy of the overlapped SV based on SV size ratio
# Returns a list of SV sizes that are unique

# reduce SV redundency based on SV size similarity
#'@export
filter_sv_by_similar_size <- function(x) {
  svs <- strsplit(x,',')
  svsn <- as.numeric(unlist(svs))
  if (length(svsn)>1){
    g <- group_sv_by_size_ratio(svsn) #TODO: Alert, if 3 SV sizes appear in the same SV region
    unique_svSize <- lapply(g,mean)
    unique_svSize <- unlist(unique_svSize)
  } else{
    unique_svSize <- svsn
  }
  return(unique_svSize)
}

# Calculate the ratio between 2 SV
get_svSize_ratio <-function(sv1, sv2){
  sv_ratio <- abs(sv1-sv2)/min(sv1,sv2)
  return(sv_ratio)
}

# Input a list of SV sizes, cluster the SV sizes by certain ratio
group_sv_by_size_ratio <- function(svSize_list) {
  svL <- sort(svSize_list)
  grouped = list()
  grouped[[1]] = svL[1]
  for (s in seq(2,length(svL))) {
    sv_ratio <- get_svSize_ratio(svL[s-1],svL[s])
    if (sv_ratio < 1){
      grouped[[length(grouped)]] <- c(grouped[[length(grouped)]],svL[s])
    } else {
      grouped <- c(grouped,svL[s])
    }
  }
  return(grouped)
}

# From the BedTools intersect result, take the matched/overlaped SV, convert SV size to positive number, check SV ratio > 0.5, return a bed dataframe of 5 columns
#'@export
filter_sizeZero_svRatio_BNG_bedintersect <- function(bedintersect_df, svratio_threshold=0.5){
  new_bed <- bedintersect_df %>%
    dplyr::filter(matches!=0) %>%
    dplyr::mutate(a_score=abs(a_score),b_score=abs(b_score)) %>%
    dplyr::mutate(svratio = abs(pmin(a_score,b_score)/pmax(a_score, b_score))) %>%
    dplyr::filter(a_score > 0) %>%
    dplyr::filter(svratio > svratio_threshold) %>%
    dplyr::select(1:5) %>%
    unique()
  return(new_bed)
}

# From the BedTools intersect result, takes a list of uncertain SV size, check SV ratio > 0.5, select the SV size that's nearest to desire size
# return a bed dataframe of 5 columns
filter_sizeZero_svRatio_BNG_bedintersect_multiSV_tmp1 <- function(bedintersect_df, svratio_threshold=0.5){
  df <- bedintersect_df %>%
    dplyr::filter(matches!=0)
  
  size_filtered <- lapply(1:nrow(df),function(i) {
    tmp_row <- df[i,,drop=F]
    ref <- tmp_row$b_score
    query_sizes <- abs(as.numeric(unlist(strsplit(tmp_row$a_score,"[|]"))))
    nearest_size <- query_sizes[which.max(lapply(query_sizes,get_size_ratio,ref,svratio_threshold))]
    return(nearest_size)
  })
  
  df_filtered<-cbind(df, "svSize"=as.integer(as.character(size_filtered)))
  new_bed <- mutate(df_filtered, a_score=svSize) %>% filter(!is.na(a_score)) %>% select(1:4,a_score)
  return(new_bed)
}

# Input a list of SV sizes, and a BNG SV size after bedtools intersection call. 
# This function will choose a nearest size comeparing the size_list and refsize.
# Return a single size for every SV. 
# get_size_ratio_list(size_list=bedintersect_df$b_score, ref_size=bedintersect_df$a_score)
#' @export
get_size_ratio_list <- function(size_list, ref_size){
  new_size <- NULL
  for (i in 1:length(size_list)){
    if (size_list[i] != "-1" & !is.na(size_list[i])){
      query_sizes <- abs(as.numeric((unlist(strsplit(size_list[i],"[|]")))))
      nearest_size <- query_sizes[which.max(sapply(query_sizes,get_size_ratio,ref_size[i]))]
    } else{
      nearest_size <- -1
    }
    new_size <- c(new_size,nearest_size)
  }
  return(new_size)
}

# This function will take a bedtools intersect result contains "a_score" to be a list of sizes, and a SV size ratio. 
#'@export
filter_sizeZero_svRatio_BNG_bedintersect_multiSV <- function(bedintersect_df, svratio_threshold=0.5){
  size_filtered <- lapply(1:nrow(bedintersect_df),function(i) {
    tmp_row <- bedintersect_df[i,,drop=F]
    ref <- tmp_row$b_score
    query_sizes <- abs(as.numeric(as.character(unlist(strsplit(tmp_row$a_score,"[|]")))))
    nearest_size <- query_sizes[which.max(lapply(query_sizes,get_size_ratio,ref))]
    return(nearest_size)
  })
  df_filtered<-cbind(bedintersect_df, "svSize"=as.integer(as.character(size_filtered)))
  df_overlapped <- df_filtered %>% dplyr::filter(matches!=0) %>% 
    rowwise() %>% 
    mutate(svRatio=get_size_ratio(svSize,b_score)) %>% 
    filter(svRatio > svratio_threshold) %>% 
    select(1:4,svSize) %>% unique() %>% mutate(overlap=1)
  df_overlapped_butLowRatio <- df_filtered %>% dplyr::filter(matches!=0) %>% 
    rowwise() %>% 
    mutate(svRatio=get_size_ratio(svSize,b_score)) %>% 
    filter(svRatio <= svratio_threshold) %>% 
    select(1:4,svSize) %>% unique() %>% mutate(overlap=0)
  df_unique <- df_filtered %>% dplyr::filter(matches==0) %>% select(1:4,svSize) %>% unique()%>% mutate(overlap=0)
  new_bed <- rbind(df_overlapped, df_unique)
  return(new_bed)
}


get_size_ratio <- function(query,ref) {
  query = abs(query)
  ref = abs(ref)
  ratio <- pmin(query,ref)/pmax(query, ref)
  return(ratio)
}

get_size_ratio_tmp <- function(query,ref,svratio_threshold) {
  query = abs(query)
  ref = abs(ref)
  ratio <- pmin(query,ref)/pmax(query, ref)
  if(ratio > svratio_threshold){
    return(ratio)
  } else{
    return(NA)
  }
}

check_size <- function(query,ref, svratio_threshold) {
  query = abs(query)
  ref = abs(ref)
  ratio <- abs(pmin(query,ref)/pmax(query, ref))
  if(ratio > svratio_threshold){
    return(TRUE)
  } else{
    return(FALSE)
  }
}

# For a bed dataframe of 5 columns, convert the SV size to positive number, standardize the column names. (tested useful to Pui's data)
#'@export
filter_sizeZero_Pui <- function(bed_pui) {
  names(bed_pui) <- c("chr", "start", "end", "id", "svSize")
  new_bed <- bed_pui %>% dplyr::filter(svSize!=0, !is.na(svSize)) %>%
    dplyr::mutate(svSize = abs(svSize))
  return(new_bed)
}


