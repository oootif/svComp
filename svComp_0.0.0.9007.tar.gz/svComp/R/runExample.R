#' @export
runExample <- function() {
  appDir <- system.file("shiny-examples", "myapp", package = "svComp")
  if (appDir == "") {
    stop("Could not find example directory. Try re-installing `svComp`.", call. = FALSE)
  }

  shiny::runApp(appDir, display.mode = "normal")
}
