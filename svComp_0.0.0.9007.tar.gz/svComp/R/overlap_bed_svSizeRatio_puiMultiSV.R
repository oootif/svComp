# bed1 5th SV size column contains multiple SV sizes, delimited by pipe "|". 
# This function will compare BNG SV size to multiple Pui's SV size. At long as one SV size meets the requirement, it's a positive SV. 
#' @export
overlap_bed_svSizeRatio_puiMultiSV <- function(bed1, bed2, svratio_threshold=0.5, optString="-wao") {
  bt_result1a <- bedTools(functionstring="intersect",bed1=bed1,bed2=bed2,optString=optString) # Overlap by 1bp
  bt_result2a <- as.data.frame(add_names_bedintersect(bt_result1a))
  bed1_analyzed <- filter_sizeZero_svRatio_BNG_bedintersect_multiSV(bedintersect_df=bt_result2a,svratio_threshold=svratio_threshold)
  bed1_overlapped <- bed1_analyzed %>% filter(overlap==1) %>% select(1:5)
  bed1_unique <- bed1_analyzed %>% filter(overlap==0) %>% select(1:5)
  bed1_overlap_wSize_unique_count <- bed1_overlapped %>% nrow
  total_bed1 <- nrow(bed1)
  bed1_all_wSize_count <- filter(bed1,!is.na(svSizes)) %>% nrow # Filter: Get all SVs that have a defined SV size (not 0), make positive.
  
  overlap_bed1 <- bed1_overlap_wSize_unique_count
  overlap_percent_bed1 <- overlap_bed1 / bed1_all_wSize_count
  bed1_unique_wSize <- bed1_all_wSize_count - overlap_bed1
  nonoverlap_percent_bed1 <- bed1_unique_wSize / bed1_all_wSize_count
  bed1a <- c(percent0(overlap_percent_bed1,digits=1),overlap_bed1, percent0(nonoverlap_percent_bed1,digits=1),bed1_unique_wSize, bed1_all_wSize_count, total_bed1)
  
  bt_result1b <- bedTools(functionstring="intersect",bed1=bed2,bed2=bed1,optString=optString)
  bt_result2b <- as.data.frame(add_names_bedintersect(bt_result1b))
  bt_result2b$b_score <- get_size_ratio_list(bt_result2b$b_score,bt_result2b$a_score) # Change b_score list to the nearest score found in last intersection
  bed_overlap_bed2 <- dplyr::filter(bt_result2b,matches!=0) # Collect the overlapped SV in bed2
  bed2_overlapped <- filter_sizeZero_svRatio_BNG_bedintersect(bed_overlap_bed2,svratio_threshold=svratio_threshold) 
  bed2_unique <- bed2 %>% filter(!SmapEntryID %in% bed2_overlapped$a_id)
  bed2_overlap_wSize_unique_count <- bed2_overlapped %>% nrow
  total_bed2 <- nrow(bed2)
  bed2_all_wSize_count <- filter_sizeZero_Pui(bed2) %>% nrow # Filter: Get all SVs that have a defined SV size (not 0), make positive.
  
  overlap_bed2 <- bed2_overlap_wSize_unique_count
  overlap_percent_bed2 <- overlap_bed2 / bed2_all_wSize_count
  bed2_unique_wSize <- bed2_all_wSize_count - overlap_bed2
  nonoverlap_percent_bed2 <- bed2_unique_wSize / bed2_all_wSize_count
  bed1b <- c(percent0(overlap_percent_bed2,digits=1),overlap_bed2, percent0(nonoverlap_percent_bed2,digits=1),bed2_unique_wSize, bed2_all_wSize_count, total_bed2)
  
  count_overlap <- rbind(bed1a,bed1b)
  colnames(count_overlap) <- c("overlap_percent","overlap_num","nonoverlap_percent","nonoverlap_num","all_noZero_SV_num","all_SV_num")
  overlap_result <- list(count_overlap, bed1_overlapped, bed2_overlapped,bed1_unique,bed2_unique,bt_result2a,bt_result2b)
  return(overlap_result)
}
